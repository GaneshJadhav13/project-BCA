<?php
include 'db_connect.php';
session_start();
include 'header.php';

// Handle login
if (isset($_POST['login'])) {
    $email    = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password FROM companies WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($company_id, $hashed_password);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $_SESSION['company_id'] = $company_id;
            header("Location: company_dashboard.php");
            exit;
        } else {
            echo '<div class="card alert">Invalid password.</div>';
        }
    } else {
        echo '<div class="card alert">No account found.</div>';
    }

    $stmt->close();
}
?>

<div class="card form-center">
  <h2>Company Login</h2>
  <form method="post">
    <label>Email</label>
    <input type="email" name="email" required>

    <label>Password</label>
    <input type="password" name="password" required>

    <button style="margin-top:7px"type="submit" name="login" class="btn">Login</button>
  </form>

  <p style="margin-top:8px">New? <a href="company_register.php">Register</a></p>
</div>

<?php include 'footer.php'; ?>
