<?php
include "db_connect.php";

if (!isset($_GET['sid'])) {
    die("Student not specified");
}

$sid = $_GET['sid'];
$resume = $conn->query("SELECT r.*, s.name AS student_name FROM resumes r
                        JOIN students s ON r.student_id=s.id
                        WHERE r.student_id=$sid")->fetch_assoc();

if (!$resume) die("Resume not found!");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Resume Preview</title>
</head>
<body>
<h1><?php echo $resume['fullname']; ?></h1>
<p>Email: <?php echo $resume['email']; ?> | Phone: <?php echo $resume['phone']; ?></p>

<h3>Summary</h3>
<p><?php echo nl2br($resume['summary']); ?></p>

<h3>Education</h3>
<p><?php echo nl2br($resume['education']); ?></p>

<h3>Skills</h3>
<p><?php echo nl2br($resume['skills']); ?></p>

<h3>Projects</h3>
<p><?php echo nl2br($resume['projects']); ?></p>

<h3>Achievements</h3>
<p><?php echo nl2br($resume['achievements']); ?></p>

<h3>Links</h3>
<p><?php echo nl2br($resume['links']); ?></p>

<hr>
<p><i>Tip: Use your browser’s Print → Save as PDF to download.</i></p>
</body>
</html>
