<?php
session_start();
include "db_connect.php";

if (!isset($_SESSION['company_id'])) {
    header("Location: login.php");
    exit();
}
$company_id = $_SESSION['company_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = $_POST['student_id'];
    $job_id = !empty($_POST['job_id']) ? "'".$_POST['job_id']."'" : "NULL"; 
    $offer_title = $_POST['offer_title'];
    $package = $_POST['package'];
    $joining_date = $_POST['joining_date'];
    $status = $_POST['status'];

    $sql = "INSERT INTO placements (student_id, company_id, job_id, offer_title, package, joining_date, status)
            VALUES ('$student_id', '$company_id', $job_id, '$offer_title', '$package', '$joining_date', '$status')";
    if ($conn->query($sql)) {
        $msg = "Placement added!";
    } else {
        $msg = "Error: ".$conn->error;
    }
}
$students = $conn->query("SELECT * FROM students");
$jobs = $conn->query("SELECT * FROM jobs WHERE company_id=$company_id");
?>
<?php include 'header.php'; ?>
<div class="card form-center" style="max-width:500px;margin:32px auto;">
    <h2 style="margin-bottom:18px;">Add Placement</h2>
    <?php if(!empty($msg)) echo "<div class='card success' style='margin-bottom:12px;'>$msg</div>"; ?>
    <form method="post">
        <label>Student</label>
        <select name="student_id" required>
            <?php while($s=$students->fetch_assoc()): ?>
                <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['name'] ?? ''); ?></option>
            <?php endwhile; ?>
        </select>

        <label>Job (optional)</label>
        <select name="job_id">
            <option value="">--None--</option>
            <?php while($j=$jobs->fetch_assoc()): ?>
                <option value="<?php echo $j['id']; ?>"><?php echo htmlspecialchars($j['title'] ?? ''); ?></option>
            <?php endwhile; ?>
        </select>

        <label>Offer Title</label>
        <input type="text" name="offer_title" required>

        <label>Package (e.g. 6 LPA)</label>
        <input type="text" name="package" required>

        <label>Joining Date</label>
        <input type="date" name="joining_date" required>

        <label>Status</label>
        <select name="status">
            <option>Offered</option>
            <option>Accepted</option>
            <option>Joined</option>
        </select>

        <button type="submit" class="btn" style="margin-top:16px">Save</button>
    </form>
</div>
<?php include 'footer.php'; ?>
