<?php
include 'db_connect.php';
include 'header.php';

$notification = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name']);
    $email   = trim($_POST['email']);
    $message = trim($_POST['message']);
    $phone   = trim($_POST['number']); // <-- fixed semicolon

    // Simple validation
    if ($name === '' || $email === '' || $message === '' || $phone === '') {
        $notification = '<div class="card alert">All fields are required.</div>';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $notification = '<div class="card alert">Invalid email format.</div>';
    } elseif (!preg_match('/^[0-9]{10}$/', $phone)) {
        $notification = '<div class="card alert">Phone number must be 10 digits.</div>';
    } else {
        // Insert into contacts table
        $stmt = $conn->prepare("INSERT INTO contacts (FullName, Email, YourMessage, Phone) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('ssss', $name, $email, $message, $phone);
        if ($stmt->execute()) {
            $notification = '<div class="card success">Thank you for contacting us! We will Reply to you soon..</div>';
        } else {
            $notification = '<div class="card alert">Error: ' . $conn->error . '</div>';
        }
        $stmt->close();
    }
}
?>


<div class="card form-center">
  <h2>Contact Us</h2>
  <?php if (!empty($notification)) echo $notification; ?>
  <form method="post">
    <label>Name</label>
    <input type="text" name="name" required>

    <label>Email</label>
    <input type="email" name="email" required>

    <label >Phone</label>
    <input type="tel" name="number" required >


    <label>Message</label>
    <textarea name="message" required></textarea>

    <button type="submit" class="btn">Send Message</button>
  </form>
</div>

<?php include 'footer.php'; ?>
