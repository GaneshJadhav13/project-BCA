<?php
include 'db_connect.php';
session_start();

if (!isset($_SESSION['company_id'])) {
    header("Location: company_login.php");
    exit;
}

include 'header.php';
$company_id = $_SESSION['company_id'];
?>

<div class="card">
  <h2>Company Dashboard</h2><br>
  <a class="btn" href="post_job.php">Post Job</a>
</div>

<div class="card">
  <h3>Your Jobs</h3>
  <table class="table">
    <tr>
      <th>Title</th>
      <th>Last Date</th>
      <th>Applicants</th>
      <th>Action</th>
    </tr>

    <?php
    $result = $conn->query("SELECT * FROM jobs WHERE company_id = $company_id ORDER BY id DESC");

    while ($row = $result->fetch_assoc()) {
        $job_id = (int)$row['id'];

        $countRes = $conn->query("SELECT COUNT(*) AS c FROM applications WHERE job_id = $job_id");
        $count    = $countRes->fetch_assoc()['c'];

        echo "
        <tr>
          <td>" . htmlspecialchars($row['title']) . "</td>
          <td>" . $row['last_date'] . "</td>
          <td>$count</td>
          <td><a class='btn' href='view_applicants.php?job_id=$job_id'>View</a></td>
        </tr>";
    }
    ?>
  </table>
</div>

<div class="card">
  <a class="btn" href="add_placement.php">Add Placement</a>
  <a class="btn" href="placed_students_company.php">Placed Students</a>
</div>

<?php include 'footer.php'; ?>
