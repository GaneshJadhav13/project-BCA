<?php
session_start();
include "db_connect.php";

// Redirect if not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// Fetch placed students
$query = "
    SELECT p.*, s.name AS student_name, c.name AS company_name
    FROM placements p
    JOIN students s ON p.student_id = s.id
    JOIN companies c ON p.company_id = c.id
";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Placed Students - Admin</title>
</head>
<body>
  <h2>All Placed Students</h2>
  <table border="1" cellpadding="5">
    <tr>
      <th>Student</th>
      <th>Company</th>
      <th>Offer Title</th>
      <th>Package</th>
      <th>Joining Date</th>
      <th>Status</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
      <tr>
  <td><?= htmlspecialchars($row['student_name'] ?? '') ?></td>
  <td><?= htmlspecialchars($row['company_name'] ?? '') ?></td>
  <td><?= htmlspecialchars($row['offer_title'] ?? '') ?></td>
  <td><?= htmlspecialchars($row['package'] ?? '') ?></td>
  <td><?= htmlspecialchars($row['joining_date'] ?? '') ?></td>
  <td><?= htmlspecialchars($row['status'] ?? '') ?></td>
      </tr>
    <?php endwhile; ?>
  </table>
</body>
</html>
