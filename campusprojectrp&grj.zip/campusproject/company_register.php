<?php
include 'db_connect.php';
include 'header.php';

// Handle registration
if (isset($_POST['register'])) {
    $name        = trim($_POST['name']);
    $email       = trim($_POST['email']);
    $password    = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $description = trim($_POST['description']);

    $stmt = $conn->prepare("INSERT INTO companies (name, email, password, description) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $password, $description);

    if ($stmt->execute()) {
        echo '<div class="card">Registration successful. <a href="company_login.php">Login</a></div>';
    } else {
        echo '<div class="card alert">Error: ' . $conn->error . '</div>';
    }

    $stmt->close();
}
?>

<div class="card form-center">
  <h2>Company Register</h2>
  <form method="post">
    <label>Company Name</label>
    <input type="text" name="name" required>

    <label>Email</label>
    <input type="email" name="email" required>

    <label>Password</label>
    <input type="password" name="password" required>

    <label>Description</label>
    <textarea name="description"></textarea>

    <button type="submit" name="register" class="btn">Register</button>
  </form>
</div>

<?php include 'footer.php'; ?>
