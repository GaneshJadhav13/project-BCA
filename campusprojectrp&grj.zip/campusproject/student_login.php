<?php
include 'db_connect.php';
include 'header.php';

session_start();

$notification = ""; //  message placeholder

if (isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $pass  = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password FROM students WHERE email = ?");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->bind_result($sid, $hash);

    if ($stmt->fetch()) {
        // verify password
        if (password_verify($pass, $hash)) {
            $_SESSION['student_id'] = $sid;

            // success message + auto redirect
            $notification = '<div class="card success">Login successful. Redirecting to dashboard...</div>';
            echo "<meta http-equiv='refresh' content='2;url=student_dashboard.php'>";
        } else {
            $notification = '<div class="card alert">Invalid password.</div>';
        }
    } else {
        $notification = '<div class="card alert">No account found.</div>';
    }

    $stmt->close();
}
?>

<div class="card form-center">
  <h2>Student Login</h2>

  <!-- Notification block above form -->
  <?php if (!empty($notification)) echo $notification; ?>

  <form method="post">
    <label>Email</label>
    <input type="email" name="email" required>

    <label>Password</label>
    <input type="password" name="password" required>

    <button type="submit" name="login" class="btn" style="margin-top:8px">Login</button>
    <p style="margin-top:8px">New? <a href="student_register.php">Register</a></p>
  </form>
</div>

<?php include 'footer.php'; ?>
