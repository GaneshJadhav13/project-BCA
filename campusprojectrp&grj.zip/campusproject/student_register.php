<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include 'db_connect.php';
include 'header.php';

$notification = ""; // Store messages here



if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $roll     = trim($_POST['roll_no']);
    $course   = $_POST['course'];
    $skills   = $_POST['skills'];

    // ✅ Simple validations
    if (!preg_match("/^[a-zA-Z ]+$/", $name)) {
        $notification = '<div class="card alert">Invalid name. Only letters and spaces allowed.</div>';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $notification = '<div class="card alert">Invalid email format.</div>';
        
    } elseif (strlen($password) < 6) {
        $notification = '<div class="card alert">Password must be at least 6 characters long.</div>';
    } elseif (!preg_match("/^[A-Za-z0-9\-]+$/", $roll)) {
        $notification = '<div class="card alert">Invalid roll number. Only letters, numbers and dashes allowed.</div>';
    } else {
        // Hash password
        $password = password_hash($password, PASSWORD_DEFAULT);

        // Check for duplicate email
        $check = $conn->prepare("SELECT id FROM students WHERE email = ?");
        $check->bind_param('s', $email);
        $check->execute();
        $check->store_result();
        if ($check->num_rows > 0) {
            $notification = '<div class="card alert">This email is already registered. Please use another email.</div>';
        } else {
            // Resume upload folder
            if (!is_dir('uploads')) {
                mkdir('uploads');
            }

            $resume_name = '';
            if (isset($_FILES['resume']) && $_FILES['resume']['error'] === 0) {
                $ext = strtolower(pathinfo($_FILES['resume']['name'], PATHINFO_EXTENSION));

                if ($ext !== 'pdf') {
                    $notification = '<div class="card alert">Only PDF allowed.</div>';
                } else {
                    $resume_name = time() . '_' . preg_replace('/\s+/', '_', $_FILES['resume']['name']);
                    if (move_uploaded_file($_FILES['resume']['tmp_name'], 'uploads/' . $resume_name)) {
                        // Insert student
                        $stmt = $conn->prepare("
                            INSERT INTO students (name, email, password, roll_no, course, skills, resume)
                            VALUES (?, ?, ?, ?, ?, ?, ?)
                        ");
                        $stmt->bind_param('sssssss', $name, $email, $password, $roll, $course, $skills, $resume_name);

                        if ($stmt->execute()) {
                            $notification = '<div class="card success">Registration successful. <a href="student_login.php">Login</a></div>';
                        } else {
                            $notification = '<div class="card alert">Error: ' . $conn->error . '</div>';
                        }
                        $stmt->close();
                    } else {
                        $notification = '<div class="card alert">Resume upload failed. Please try again or use a smaller file.";</div>';
                    }
                }
            }
        }
        $check->close();
    }
}

// Fallback notification if registration logic is skipped
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($notification)) {
    $notification = '<div class="card alert">Registration did not complete. Please check your input and try again.</div>';
}
?>

<div class="card form-center">
  <h2>Student Registration</h2>

  <!-- ✅ Notification above form -->
  <?php if (!empty($notification)) echo $notification; ?>

  <form method="post" enctype="multipart/form-data">
    <label>Name</label>
    <input type="text" name="name" required>

    <label>Email</label>
    <input type="email" name="email" required>

    <label>Password</label>
    <input type="password" name="password" required>

    <label>Roll No</label>
    <input type="text" name="roll_no" required>

    <label>Course</label>
    <input type="text" name="course" required>

    <label>Skills</label>
    <textarea name="skills" required></textarea>

    <label>Resume (PDF)</label>
    <input type="file" name="resume" accept=".pdf" required>

    <button type="submit" name="register" class="btn" style="margin-top:8px">Register</button>
  </form>
</div>

<?php include 'footer.php'; ?>
