<?php
session_start();
include "db_connect.php";
if (!isset($_SESSION['company_id'])) {
    header("Location: login.php"); exit();
}
$cid = $_SESSION['company_id'];
// Fetch placed students for this company
$res = $conn->query("SELECT p.*, s.name AS student_name
                     FROM placements p
                     JOIN students s ON p.student_id=s.id
                     WHERE p.company_id=$cid");
$hasRows = ($res && $res->num_rows > 0);
?>
<!DOCTYPE html>
<html>
<head>
<title>Placed Students - Company</title>
</head>
<body>
<h2>Placed Students</h2>
<table border="1" cellpadding="5">
<tr><th>Student</th><th>Offer Title</th><th>Package</th><th>Joining Date</th><th>Status</th></tr>
<?php if ($hasRows): ?>
  <?php while($row=$res->fetch_assoc()): ?>
    <tr>
      <td><?php echo $row['student_name']; ?></td>
      <td><?php echo $row['offer_title']; ?></td>
      <td><?php echo $row['package']; ?></td>
      <td><?php echo $row['joining_date']; ?></td>
      <td><?php echo $row['status']; ?></td>
    </tr>
  <?php endwhile; ?>
<?php else: ?>
  <tr><td colspan="5" style="text-align:center; color:#888;">No placed students found.</td></tr>
<?php endif; ?>
</table>
</body>
</html>
