<?php
session_start();
include "db_connect.php";

// If not logged in, redirect to login
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// Save form data when submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname    = $_POST['fullname'];
    $email       = $_POST['email'];
    $phone       = $_POST['phone'];
    $summary     = $_POST['summary'];
    $education   = $_POST['education'];
    $skills      = $_POST['skills'];
    $projects    = $_POST['projects'];
    $achievements= $_POST['achievements'];
    $links       = $_POST['links'];

    // Insert or update resume record
    $sql = "
    INSERT INTO resumes 
        (student_id, fullname, email, phone, summary, education, skills, projects, achievements, links)
    VALUES 
        ('$student_id','$fullname','$email','$phone','$summary','$education','$skills','$projects','$achievements','$links')
    ON DUPLICATE KEY UPDATE
        fullname='$fullname', 
        email='$email', 
        phone='$phone',
        summary='$summary', 
        education='$education', 
        skills='$skills',
        projects='$projects', 
        achievements='$achievements', 
        links='$links'
    ";

    if ($conn->query($sql)) {
        $message = "Resume saved successfully!";
    } else {
        $message = "Error: " . $conn->error;
    }
}

// Fetch existing resume data if available
$resume = $conn->query("SELECT * FROM resumes WHERE student_id=$student_id")->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Resume Builder</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        h2 {
            text-align: center;
            padding: 20px;
            color: #333;
        }
        form {
            width: 80%;
            max-width: 700px;
            background: #fff;
            padding: 25px;
            margin: 0 auto;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        label {
            display: block;
            margin-top: 12px;
            font-weight: bold;
            color: #444;
        }
        input[type="text"], 
        input[type="email"], 
        textarea {
            width: 100%;
            padding: 8px 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 14px;
        }
        textarea {
            min-height: 60px;
        }
        input[type="submit"] {
            background: #4CAF50;
            color: white;
            padding: 10px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 18px;
            font-size: 15px;
        }
        input[type="submit"]:hover {
            background: #45a049;
        }
        .message {
            text-align: center;
            color: green;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .link-container {
            text-align: center;
            margin-top: 20px;
        }
        .link-container a {
            color: #0066cc;
            text-decoration: none;
        }
        .link-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<h2>Resume Builder</h2>

<?php if (!empty($message)) echo "<p class='message'>$message</p>"; ?>

<form method="post">
    <label>Full Name:</label>
    <input type="text" name="fullname" value="<?php echo $resume['fullname'] ?? ''; ?>">

    <label>Email:</label>
    <input type="email" name="email" value="<?php echo $resume['email'] ?? ''; ?>">

    <label>Phone:</label>
    <input type="text" name="phone" value="<?php echo $resume['phone'] ?? ''; ?>">

    <label>Summary:</label>
    <textarea name="summary"><?php echo $resume['summary'] ?? ''; ?></textarea>

    <label>Education:</label>
    <textarea name="education"><?php echo $resume['education'] ?? ''; ?></textarea>

    <label>Skills:</label>
    <textarea name="skills"><?php echo $resume['skills'] ?? ''; ?></textarea>

    <label>Projects:</label>
    <textarea name="projects"><?php echo $resume['projects'] ?? ''; ?></textarea>

    <label>Achievements:</label>
    <textarea name="achievements"><?php echo $resume['achievements'] ?? ''; ?></textarea>

    <label>Links (e.g. GitHub, LinkedIn):</label>
    <textarea name="links"><?php echo $resume['links'] ?? ''; ?></textarea>

    <input type="submit" value="Save Resume">
</form>

<div class="link-container">
    <a href="resume_preview.php?sid=<?php echo $student_id; ?>">Preview / Download Resume</a>
</div>

</body>
</html>
