<?php
include 'db_connect.php';
session_start();

// Redirect if not logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

include 'header.php';

// Handle form submission
if (isset($_POST['post'])) {
    $title   = $_POST['title'];
    $message = $_POST['message'];
    $date    = $_POST['date_posted'];

    $stmt = $conn->prepare("INSERT INTO announcements (title, message, date_posted) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $title, $message, $date);

    if ($stmt->execute()) {
        echo '<div class="card">Posted.</div>';
    } else {
        echo '<div class="card">Error: ' . $conn->error . '</div>';
    }
    $stmt->close();
}
?>

<div class="card form-center">
  <h2>Post Announcement</h2>
  <form method="post">
    <label>Title</label>
    <input type="text" name="title" required>

    <label>Message</label>
    <textarea name="message" required></textarea>

    <label>Date</label>
    <input type="date" name="date_posted" required>

    <button class="btn" type="submit" name="post">Post</button>
  </form>
</div>

<?php include 'footer.php'; ?>
