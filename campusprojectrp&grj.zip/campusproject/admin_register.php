<?php
include 'db_connect.php';
include 'header.php';

// Handle registration
if (isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO admin (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $password);

    if ($stmt->execute()) {
        echo '<div class="card">Registration successful. <a href="admin_login.php">Login</a></div>';
    } else {
        echo '<div class="card alert">Error: ' . $conn->error . '</div>';
    }

    $stmt->close();
}
?>

<div class="card form-center">
  <h2>Admin Registration</h2>
  <form method="post" enctype="multipart/form-data">
    <label>Username</label>
    <input type="text" name="username" required>

    <label>Password</label>
    <input type="password" name="password" required>

    <button type="submit" name="register" class="btn" style="margin-top:8px">Register</button>
  </form>
</div>

<?php include 'footer.php'; ?>
