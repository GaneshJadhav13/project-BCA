<?php
include 'db_connect.php';
session_start();

// Redirect if not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

include 'header.php';

// Fetch companies
$result = $conn->query("SELECT * FROM companies ORDER BY id DESC");
?>

<div class="card">
  <h2>All Companies</h2>
  <table class="table">
    <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Description</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td><?= htmlspecialchars($row['email']) ?></td>
        <td><?= nl2br(htmlspecialchars($row['description'])) ?></td>
      </tr>
    <?php endwhile; ?>
  </table>
</div>

<?php include 'footer.php'; ?>
