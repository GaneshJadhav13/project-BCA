<?php
include 'db_connect.php';
session_start();

// Redirect if not logged in
if (!isset($_SESSION['student_id'])) {
    header('Location: student_login.php');
    exit;
}

include 'header.php';

// Search/filter setup
$q = isset($_GET['q']) ? trim($conn->real_escape_string($_GET['q'])) : '';
$company_filter = isset($_GET['company']) ? intval($_GET['company']) : 0;

$where = "1=1";
if ($q !== '') {
    $where .= " AND (jobs.title LIKE '%$q%' OR jobs.description LIKE '%$q%' OR companies.name LIKE '%$q%')";
}
if ($company_filter > 0) {
    $where .= " AND companies.id = $company_filter";
}
?>

<div class="card">
  <h2>Student Dashboard</h2>
  <p>Welcome to your dashboard. See announcements, browse jobs and apply.</p>
</div>

<div class="card ticker">
  <?php
  $ann = $conn->query("SELECT title, message FROM announcements ORDER BY date_posted DESC LIMIT 10");
  $items = [];
  while ($r = $ann->fetch_assoc()) {
      $items[] = htmlspecialchars($r['title'] . ' - ' . $r['message']);
  }
  echo '<p>' . implode(' • ', $items) . '</p>';
  ?>
</div>

<div class="card">
  <form method="get" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
    <input type="text" name="q" placeholder="Search jobs or companies..." value="<?php echo htmlspecialchars($q); ?>">

    <select name="company">
      <option value="0">All companies</option>
      <?php
      $cres = $conn->query("SELECT id, name FROM companies ORDER BY name");
      while ($c = $cres->fetch_assoc()) {
          $sel = ($company_filter == $c['id']) ? 'selected' : '';
          echo '<option value="' . $c['id'] . '" ' . $sel . '>' . htmlspecialchars($c['name']) . '</option>';
      }
      ?>
    </select>

    <button class="btn" type="submit">Search</button>
    <a class="btn secondary" href="student_dashboard.php" style="text-decoration:none">Reset</a>
  </form>
</div>

<div class="card">
  <h3>Open Jobs</h3>
  <table class="table">
    <tr><th>Job</th><th>Company</th><th>Last Date</th><th>Action</th></tr>
    <?php
    $sql = "SELECT jobs.*, companies.name AS company_name
            FROM jobs 
            JOIN companies ON jobs.company_id = companies.id
            WHERE $where ORDER BY jobs.id DESC";
    $res = $conn->query($sql);

  $sid = $_SESSION['student_id'];
  while ($row = $res->fetch_assoc()) {
    echo '<tr>';
    echo '<td>' . htmlspecialchars($row['title']) .
       '<div style="color:var(--muted);font-size:13px">' .
       nl2br(htmlspecialchars($row['description'])) . '</div></td>';
    echo '<td>' . htmlspecialchars($row['company_name']) . '</td>';
    echo '<td>' . $row['last_date'] . '</td>';

    // Check if already applied
    $job_id = $row['id'];
    $app_check = $conn->query("SELECT id FROM applications WHERE student_id = $sid AND job_id = $job_id");
    if ($app_check && $app_check->num_rows > 0) {
      echo '<td><button class="btn" style="background:#aaa;cursor:not-allowed" disabled>Applied</button></td>';
    } else {
      echo '<td><a class="btn" href="apply_job.php?id=' . $row['id'] . '">Apply</a></td>';
    }
    echo '</tr>';
  }
    ?>
  </table>
</div>

<div class="card">
  <h3>Your Applications</h3>
  <table class="table">
    <tr><th>Job</th><th>Company</th><th>Status</th></tr>
    <?php
    $sid = $_SESSION['student_id'];
    $sql = "SELECT applications.status, jobs.title, companies.name AS company_name
            FROM applications
            JOIN jobs ON applications.job_id = jobs.id
            JOIN companies ON jobs.company_id = companies.id
            WHERE applications.student_id = $sid
            ORDER BY applications.id DESC";
    $res = $conn->query($sql);

    while ($row = $res->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . htmlspecialchars($row['title']) . '</td>';
        echo '<td>' . htmlspecialchars($row['company_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['status']) . '</td>';
        echo '</tr>';
    }
    ?>
  </table>
</div>

<a class="btn" href="student_resume_builder.php">Resume Builder</a>

<?php include 'footer.php'; ?>
