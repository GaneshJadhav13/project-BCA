<?php
session_start();
include 'db_connect.php';
include 'header.php';

// Handle login
if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password FROM admin WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($admin_id, $hashed_password);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $_SESSION['admin_id'] = $admin_id;
            header("Location: admin_dashboard.php");
            exit;
        } else {
            echo '<div class="card alert">Invalid password.</div>';
        }
    } else {
        echo '<div class="card alert">No such user.</div>';
    }

    $stmt->close();
}
?>

<div class="card form-center">
  <h2>Admin Login</h2>
  <form method="post">
    <label>Username</label>
    <input type="text" name="username" required>

    <label>Password</label>
    <input type="password" name="password" required>

    <button style="margin-top:7px"class="btn" type="submit" name="login">Login</button>
  </form>

  <p style="margin-top:8px"><em>Default admin: admin / admin123 (create via SQL)</em></p>
  <p style="margin-top:8px">New? <a href="admin_register.php">Register</a></p>
</div>

<?php include 'footer.php'; ?>
