<?php
include 'db_connect.php';
session_start();

// Authentication check
if (!isset($_SESSION['company_id'])) {
    header('Location: company_login.php');
    exit;
}

include 'header.php';

// Validate job_id
$job_id = isset($_GET['job_id']) ? intval($_GET['job_id']) : 0;
if ($job_id <= 0) die('Invalid');

$cid = $_SESSION['company_id'];
$chk = $conn->query("SELECT id FROM jobs WHERE id = $job_id AND company_id = $cid");
if ($chk->num_rows == 0) die('Unauthorized');

// Update applicant status
if (isset($_GET['set'], $_GET['app_id'])) {
  $new    = $_GET['set'];
  $app_id = intval($_GET['app_id']);
  $allowed = ['Pending','Shortlisted','Selected','Rejected'];

  if (in_array($new, $allowed)) {
    $stmt = $conn->prepare("UPDATE applications SET status = ? WHERE id = ?");
    $stmt->bind_param('si', $new, $app_id);
    $stmt->execute();
    $stmt->close();
  }

  header("Location: view_applicants.php?job_id=$job_id");
  exit;
}

// Add to placements if requested
if (isset($_GET['place'], $_GET['student_id'])) {
  $student_id = intval($_GET['student_id']);
  $job_id = intval($_GET['job_id']);
  $company_id = $_SESSION['company_id'];

  // Get job details
  $job = $conn->query("SELECT title FROM jobs WHERE id = $job_id")->fetch_assoc();
  $offer_title = $job ? $job['title'] : '';

  // Avoid duplicate placements
  $exists = $conn->query("SELECT id FROM placements WHERE student_id = $student_id AND company_id = $company_id AND job_id = $job_id")->num_rows;
  if (!$exists) {
    $stmt = $conn->prepare("INSERT INTO placements (student_id, company_id, job_id, offer_title, status) VALUES (?, ?, ?, ?, 'Offered')");
    $stmt->bind_param('iiis', $student_id, $company_id, $job_id, $offer_title);
    $stmt->execute();
    $stmt->close();
  }
  header("Location: view_applicants.php?job_id=$job_id");
  exit;
}
?>

<div class="card">
  <h2>Applicants</h2>
  <table class="table">
    <tr>
      <th>Student</th>
      <th>Course</th>
      <th>Skills</th>
      <th>Resume</th>
      <th>Status</th>
      <th>Update</th>
    </tr>

    <?php
    $sql = "
      SELECT 
        applications.id AS app_id,
        applications.status,
        applications.student_id,
        students.name,
        students.course,
        students.skills,
        students.resume
      FROM applications
      JOIN students ON applications.student_id = students.id
      WHERE applications.job_id = $job_id
      ORDER BY applications.id DESC
    ";

    $res = $conn->query($sql);
    while ($row = $res->fetch_assoc()):
        $resume = $row['resume']
            ? '<a class="btn" target="_blank" href="uploads/' . htmlspecialchars($row['resume']) . '">View</a>'
            : '—';
        $addPlacementBtn = '';
        if ($row['status'] === 'Selected') {
            // Check if already placed
            $alreadyPlaced = $conn->query("SELECT id FROM placements WHERE student_id = {$row['student_id']} AND company_id = $cid AND job_id = $job_id")->num_rows;
            if (!$alreadyPlaced) {
                $addPlacementBtn = '<a class="" style="background:#28a745;color:#fff;" href="?job_id=' . $job_id . '&student_id=' . $row['student_id'] . '&place=1"></a>';
            } else {
                $addPlacementBtn = '<span style="color:#28a745;">Placed</span>';
            }
        }
    ?>
      <tr>
  <td><?= htmlspecialchars($row['name'] ?? '') ?></td>
  <td><?= htmlspecialchars($row['course'] ?? '') ?></td>
  <td><?= nl2br(htmlspecialchars($row['skills'] ?? '')) ?></td>
        <td><?= $resume ?></td>
        <td><?= htmlspecialchars($row['status']) ?></td>
        <td>
          <a class="btn" href="?job_id=<?= $job_id ?>&app_id=<?= $row['app_id'] ?>&set=Shortlisted">Shortlist</a>
          <a class="btn" href="?job_id=<?= $job_id ?>&app_id=<?= $row['app_id'] ?>&set=Selected">Select</a>
          <a class="btn" href="?job_id=<?= $job_id ?>&app_id=<?= $row['app_id'] ?>&set=Rejected">Reject</a>
          <?= $addPlacementBtn ?>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>
</div>

<?php include 'footer.php'; ?>
