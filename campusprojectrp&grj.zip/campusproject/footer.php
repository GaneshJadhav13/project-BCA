</main>
<footer class="site-footer">
  <div class="wrap">
    <div class="foot-left">
      <strong style="padding:4px; margin:4px; display:inline-block;">Placement Portal</strong>

      <p style="padding:4px; margin:4px;" >Our Placement Portal bridges the gap between<br> 
        students and recruiters by offering a simple, transparent, and efficient way to connect.<br> 
        From registration to interviews, everything is managed smoothly in a single platform.</p>
    </div>
    <div style="padding:4px; margin:4px;" class="foot-right" id="contact">
      <h4 >Contact</h4>
      <p>Email: placementportal@gmail.com</p>
      <p>Phone: +91 70000 00000</p>


    </div>

    
  </div>
  <b><div class="small"; style="color:black">© <?php echo date('Y'); ?> Student Placement Portal | All Rights Reserved</div></b>
</footer>
<script>
// Simple nav toggle for mobile
document.addEventListener('DOMContentLoaded', function(){
  var btn = document.querySelector('.nav-toggle');
  var nav = document.querySelector('.main-nav');
  if(btn){ btn.addEventListener('click', function(){ nav.classList.toggle('open'); }); }
});
</script>
</body>
</html>
