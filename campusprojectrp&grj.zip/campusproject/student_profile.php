<?php 
include 'db_connect.php'; 
session_start();

if (!isset($_SESSION['student_id'])) {
    header('Location: student_login.php');
    exit;
}

include 'header.php'; 
?>

<?php
$sid = $_SESSION['student_id'];

if (isset($_POST['save'])) {
    $name   = $_POST['name']; 
    $roll   = $_POST['roll_no']; 
    $course = $_POST['course']; 
    $skills = $_POST['skills'];

    if (!is_dir('uploads')) {
        mkdir('uploads');
    }

    $picname = '';

    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === 0) {
        $ext     = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
        $picname = time() . '' . preg_replace('/\s+/', '', $_FILES['photo']['name']);

        move_uploaded_file($_FILES['photo']['tmp_name'], 'uploads/' . $picname);

        $stmt = $conn->prepare(
            'UPDATE students 
             SET resume = ? 
             WHERE id = ?'
        );
        $stmt->bind_param('si', $picname, $sid);
        $stmt->execute();
        $stmt->close();

        $_SESSION['photo_updated'] = time();
    }

    $stmt = $conn->prepare(
        'UPDATE students 
         SET name   = ?, 
             roll_no = ?, 
             course  = ?, 
             skills  = ? 
         WHERE id = ?'
    );
    $stmt->bind_param('ssssi', $name, $roll, $course, $skills, $sid);

    if ($stmt->execute()) {
        $_SESSION['profile_updated'] = time();
    } else {
        echo '<div class="card">Error: ' . $conn->error . '</div>';
    }

    if (isset($_SESSION['profile_updated']) && (time() - $_SESSION['profile_updated'] <= 60)) {
        echo '<div id="profile-updated-msg" class="card" style="background:#d1ecf1;color:#0c5460;">Profile updated.</div>';
        echo '<script>
                setTimeout(function(){
                    var el = document.getElementById("profile-updated-msg"); 
                    if(el) el.style.display = "none"; 
                }, 60000);
              </script>';
    } elseif (isset($_SESSION['profile_updated'])) {
        unset($_SESSION['profile_updated']);
    }

    if (isset($_SESSION['photo_updated']) && (time() - $_SESSION['photo_updated'] <= 60)) {
        echo '<div id="photo-updated-msg" class="card" style="background:#d4edda;color:#155724;">Profile photo updated successfully!</div>';
        echo '<script>
                setTimeout(function(){ 
                    var el = document.getElementById("photo-updated-msg"); 
                    if(el) el.style.display = "none"; 
                }, 60000);
              </script>';
    } elseif (isset($_SESSION['photo_updated'])) {
        unset($_SESSION['photo_updated']);
    }

    $stmt->close();
}

$res = $conn->query('SELECT * FROM students WHERE id=' . $sid);
$me  = $res->fetch_assoc();
?>

<div class="card">
  <h2>Your Profile</h2>

  <div style="display:flex; gap:18px; align-items:center; flex-wrap:wrap">
    <!-- Profile Photo (default logo if not uploaded) -->
    <img 
      src="<?php echo ($me['resume'] ?? null) 
                ? 'uploads/' . htmlspecialchars($me['resume']) 
                : 'assets/images/logo.png'; ?>" 
      alt="profile" 
      class="profile-img"
    >

    <div>
      <h3><?php echo htmlspecialchars($me['name'] ?? ''); ?></h3>
      <p style="color:var(--muted)">
        <?php echo htmlspecialchars($me['email'] ?? ''); ?>
      </p>

      <p>
        <strong>Roll:</strong> <?php echo htmlspecialchars($me['roll_no'] ?? ''); ?><br>
        <strong>Course:</strong> <?php echo htmlspecialchars($me['course'] ?? ''); ?><br>
        <strong>Skills:</strong> <?php echo htmlspecialchars($me['skills'] ?? ''); ?><br>
      </p>

      <?php if (!empty($me['resume'])): ?>
        <p>
          <strong>Resume:</strong> 
          <a href="uploads/<?php echo htmlspecialchars($me['resume']); ?>" target="_blank">
            View Resume
          </a>
        </p>
      <?php endif; ?>
    </div>
  </div>
</div>


<div class="card form-center">
  <h3>Edit Profile</h3>

  <form method="post" enctype="multipart/form-data">
    <label>Name</label>
    <input type="text" name="name" value="<?php echo htmlspecialchars($me['name'] ?? ''); ?>" required>

    <label>Roll No</label>
    <input type="text" name="roll_no" value="<?php echo htmlspecialchars($me['roll_no'] ?? ''); ?>" required>

    <label>Course</label>
    <input type="text" name="course" value="<?php echo htmlspecialchars($me['course'] ?? ''); ?>" required>

    <label>Skills</label>
    <textarea name="skills" required><?php echo htmlspecialchars($me['skills'] ?? ''); ?></textarea>

    <label>Profile Photo (optional)</label>
    <input type="file" name="photo" accept="image/*">

    <button type="submit" name="save" class="btn">Save</button>
  </form>
</div>

<?php include 'footer.php'; ?>