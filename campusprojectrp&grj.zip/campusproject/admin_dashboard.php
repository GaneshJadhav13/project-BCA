<?php include 'db_connect.php'; session_start(); if(!isset($_SESSION['admin_id'])){ header('Location: admin_login.php'); exit;} include 'header.php'; ?>
<div class="card">
  <h2>Admin Dashboard</h2>
  <div class="flex" style="display:flex;gap:12px;flex-wrap:wrap">
    <a class="btn" href="manage_students.php">Manage Students</a>
    <a class="btn" href="manage_companies.php">Manage Companies</a>
    <a class="btn" href="post_announcement.php">Post Announcement</a>
    <a class="btn" href="placed_students_admin.php">Placed Students</a>
  </div>
</div>
<div class="card">
  <h3>Quick Stats</h3>
  <div style="display:flex;gap:12px;flex-wrap:wrap">
    <div class="card" style="flex:1">
      <?php $s=$conn->query('SELECT COUNT(*) AS c FROM students')->fetch_assoc()['c']; ?>
      <h4>Total Students</h4><p><strong><?php echo $s; ?></strong></p>
    </div>
    <div class="card" style="flex:1">
      <?php $c=$conn->query('SELECT COUNT(*) AS c FROM companies')->fetch_assoc()['c']; ?>
      <h4>Total Companies</h4><p><strong><?php echo $c; ?></strong></p>
    </div>
    <div class="card" style="flex:1">
      <?php $j=$conn->query('SELECT COUNT(*) AS c FROM jobs')->fetch_assoc()['c']; ?>
      <h4>Total Jobs</h4><p><strong><?php echo $j; ?></strong></p>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>
