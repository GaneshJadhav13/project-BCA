<?php
include 'db_connect.php';
session_start();

// Check login
if (!isset($_SESSION['student_id'])) {
    header("Location: student_login.php");
    exit;
}

$student_id = $_SESSION['student_id'];
$job_id     = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($job_id <= 0) {
    die("Invalid Job ID");
}

// Check if already applied
$stmt = $conn->prepare("SELECT id FROM applications WHERE student_id = ? AND job_id = ?");
$stmt->bind_param("ii", $student_id, $job_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo "<script>alert('Already applied');window.location='student_dashboard.php';</script>";
    exit;
}
$stmt->close();

// Insert new application
$stmt = $conn->prepare("INSERT INTO applications (student_id, job_id, status) VALUES (?, ?, 'Pending')");
$stmt->bind_param("ii", $student_id, $job_id);

if ($stmt->execute()) {
    echo "<script>alert('Application submitted');window.location='student_dashboard.php';</script>";
} else {
    echo "Error: " . $conn->error;
}

$stmt->close();
?>
