<?php
include 'db_connect.php';
session_start();

// Redirect if not logged in
if (!isset($_SESSION['company_id'])) {
    header("Location: company_login.php");
    exit;
}

include 'header.php';

// Handle form submission
if (isset($_POST['post'])) {
    $cid   = $_SESSION['company_id'];
    $title = $_POST['title'];
    $desc  = $_POST['description'];
    $elig  = $_POST['eligibility'];
    $last  = $_POST['last_date'];

    $stmt = $conn->prepare("
        INSERT INTO jobs (company_id, title, description, eligibility, last_date)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("issss", $cid, $title, $desc, $elig, $last);

    if ($stmt->execute()) {
        header("Location: company_dashboard.php");
        exit;
    } else {
        echo '<div class="card">Error: ' . $conn->error . '</div>';
    }
    $stmt->close();
}
?>

<div class="card form-center">
  <h2>Post a Job</h2>
  <form method="post">
    <label>Title</label>
    <input type="text" name="title" required>

    <label>Description</label>
    <textarea name="description" required></textarea>

    <label>Eligibility</label>
    <textarea name="eligibility" required></textarea>

    <label>Last Date</label>
    <input type="date" name="last_date" required>

    <button type="submit" name="post" class="btn">Post Job</button>
  </form>
</div>

<?php include 'footer.php'; ?>
