<?php
// Serve uploaded resume files with permission checks, or redirect to resume_preview.php if built.
include 'db_connect.php';
session_start();

$sid = isset($_GET['sid']) ? intval($_GET['sid']) : 0;
$job_id = isset($_GET['job_id']) ? intval($_GET['job_id']) : 0;
if ($sid <= 0) { http_response_code(400); echo 'Invalid student id'; exit; }

// Permission: admin OR owner student OR company that has an application for this student
$is_admin = isset($_SESSION['admin_id']);
$is_student = isset($_SESSION['student_id']) && $_SESSION['student_id'] == $sid;
$is_company = isset($_SESSION['company_id']);
$company_id = $is_company ? $_SESSION['company_id'] : 0;
$allowed = false;

if ($is_admin || $is_student) {
    $allowed = true;
}

if (!$allowed && $is_company) {
    // If job_id provided, restrict check to that job; otherwise check any job owned by company
    if ($job_id > 0) {
        $chk = $conn->prepare('SELECT a.id FROM applications a JOIN jobs j ON a.job_id=j.id WHERE a.student_id=? AND j.id=? AND j.company_id=? LIMIT 1');
        $chk->bind_param('iii', $sid, $job_id, $company_id);
    } else {
        $chk = $conn->prepare('SELECT a.id FROM applications a JOIN jobs j ON a.job_id=j.id WHERE a.student_id=? AND j.company_id=? LIMIT 1');
        $chk->bind_param('ii', $sid, $company_id);
    }
    $chk->execute();
    $res = $chk->get_result();
    if ($res && $res->num_rows > 0) $allowed = true;
    if ($res) $res->free();
    $chk->close();
}

if (!$allowed) {
    http_response_code(403);
    echo 'Access denied';
    exit;
}

// Fetch student's resume filename
$sstmt = $conn->prepare('SELECT resume FROM students WHERE id = ? LIMIT 1');
$sstmt->bind_param('i', $sid);
$sstmt->execute();
$sres = $sstmt->get_result();
$row = $sres ? $sres->fetch_assoc() : null;
$sstmt->close();

if ($row && !empty($row['resume'])) {
    $filename = basename($row['resume']);
    $path = __DIR__ . '/uploads/' . $filename;
    if (file_exists($path) && is_readable($path)) {
        // Serve file
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($path) ?: 'application/octet-stream';
        header('Content-Type: ' . $mime);
        header('Content-Disposition: inline; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }
}

// Fall back to resume_preview.php (resume builder)
// If no uploaded file, check the resumes table
$rstmt = $conn->prepare('SELECT id FROM resumes WHERE student_id = ? LIMIT 1');
$rstmt->bind_param('i', $sid);
$rstmt->execute();
$rres = $rstmt->get_result();
$has = $rres ? $rres->fetch_assoc() : null;
$rstmt->close();
if ($has) {
    header('Location: resume_preview.php?sid=' . intval($sid));
    exit;
}

http_response_code(404);
echo 'Resume not found.';
exit;
?>