<?php
include "db_connect.php";

// validate and cast sid
$sid = isset($_GET['sid']) ? intval($_GET['sid']) : 0;
if ($sid <= 0) {
    die("Student not specified or invalid");
}

$stmt = $conn->prepare("SELECT r.*, s.name AS student_name FROM resumes r JOIN students s ON r.student_id=s.id WHERE r.student_id = ?");
$stmt->bind_param('i', $sid);
$stmt->execute();
$result = $stmt->get_result();
$resume = $result ? $result->fetch_assoc() : null;
$stmt->close();

if (!$resume) die("Resume not found!");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Resume Preview</title>
</head>
<body>
<h1><?php echo htmlspecialchars($resume['fullname'] ?? ''); ?></h1>
<p>Email: <?php echo htmlspecialchars($resume['email'] ?? ''); ?> | Phone: <?php echo htmlspecialchars($resume['phone'] ?? ''); ?></p>

<h3>Summary</h3>
<p><?php echo nl2br(htmlspecialchars($resume['summary'] ?? '')); ?></p>

<h3>Education</h3>
<p><?php echo nl2br(htmlspecialchars($resume['education'] ?? '')); ?></p>

<h3>Skills</h3>
<p><?php echo nl2br(htmlspecialchars($resume['skills'] ?? '')); ?></p>

<h3>Projects</h3>
<p><?php echo nl2br(htmlspecialchars($resume['projects'] ?? '')); ?></p>

<h3>Achievements</h3>
<p><?php echo nl2br(htmlspecialchars($resume['achievements'] ?? '')); ?></p>

<h3>Links</h3>
<p><?php echo nl2br(htmlspecialchars($resume['links'] ?? '')); ?></p>

<hr>
<p><i>Tip: Use your browser’s Print → Save as PDF to download.</i></p>
</body>
</html>
