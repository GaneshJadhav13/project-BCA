<?php
include 'db_connect.php';
include 'header.php';

// Handle registration

$notification = "";
if (isset($_POST['register'])) {
  $name        = trim($_POST['name']);
  $email       = trim($_POST['email']);
  $password    = $_POST['password'];
  $confirm_password = $_POST['confirm_password'];
  $description = trim($_POST['description']);

  // Name validation
  if (!preg_match("/^[a-zA-Z0-9 .,'&()-]+$/", $name) || empty($name)) {
    $notification = '<div class="card alert">Invalid company name. Only letters, numbers, spaces, and basic punctuation allowed.</div>';
  // Email validation
  } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $notification = '<div class="card alert">Invalid email format.</div>';
  // Password length
  } elseif (strlen($password) < 6) {
    $notification = '<div class="card alert">Password must be at least 6 characters long.</div>';
  // Password confirmation
  } elseif ($password !== $confirm_password) {
    $notification = '<div class="card alert">Passwords do not match.</div>';
  // Description validation
  } elseif (empty($description) || strlen($description) < 5 || strlen($description) > 500) {
    $notification = '<div class="card alert">Please enter a company description (5-500 characters).</div>';
  } else {
    // Check for duplicate email
    $check = $conn->prepare("SELECT id FROM companies WHERE email = ?");
    $check->bind_param('s', $email);
    $check->execute();
    $check->store_result();
    if ($check->num_rows > 0) {
      $notification = '<div class="card alert">This email is already registered. Please use another email.</div>';
    } else {
      $password_hashed = password_hash($password, PASSWORD_DEFAULT);
      $stmt = $conn->prepare("INSERT INTO companies (name, email, password, description) VALUES (?, ?, ?, ?)");
      $stmt->bind_param("ssss", $name, $email, $password_hashed, $description);
      if ($stmt->execute()) {
        $notification = '<div class="card">Registration successful. <a href="company_login.php">Login</a></div>';
      } else {
        $notification = '<div class="card alert">Error: ' . $conn->error . '</div>';
      }
      $stmt->close();
    }
    $check->close();
  }
}
?>

<div class="card form-center">
  <h2>Company Register</h2>
  <?php if (!empty($notification)) echo $notification; ?>
  <form method="post">
    <label>Company Name</label>
    <input type="text" name="name" required>

    <label>Email</label>
    <input type="email" name="email" required>

    <label>Password</label>
    <input type="password" name="password" required>

    <label>Confirm Password</label>
    <input type="password" name="confirm_password" required>

    <label>Description</label>
    <textarea name="description" required></textarea>

    <button type="submit" name="register" class="btn">Register</button>
  </form>
</div>

<?php include 'footer.php'; ?>
