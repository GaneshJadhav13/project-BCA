<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color"content="#9ffcceff">
  <link rel="icon" type="image/png"href=assets/images/icon.jpg>
  <title>Student Placement Portal</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/styles.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  
</head>
<body>
<header class="site-header">
  <div class="wrap">
    <div class="brand">
      <a href="index.php"><img src="assets/images/logo1.jpg" alt="logo" class="logo"> 
      <span style="font-family:poppins;font-size:20px;font-weight:700;color:white;margin-bottom:2px;letter-spacing:1px;" >Placement Portal</span></a>
    </div>
    <nav class="main-nav">
      <a href="index.php">Home</a>
      <?php 
        // Prefer Admin -> Company -> Student when multiple session roles exist
        if (isset($_SESSION['admin_id'])): ?>
        <a href="admin_dashboard.php">Admin</a>
      <?php elseif (isset($_SESSION['company_id'])): ?>
        <a href="company_dashboard.php">Company</a>
      <?php elseif (isset($_SESSION['student_id'])): ?>
        <a href="student_dashboard.php">Student</a>
        <a href="student_profile.php">Profile</a>
      <?php else: ?>
        <a href="student_login.php">Student Login</a>
        <a href="company_login.php">Company Login</a>
        <a href="admin_login.php">Admin Login</a>

      <?php endif; ?>
      <a href="about.php#developers">Contact</a>
      <?php if(isset($_SESSION['student_id'])||isset($_SESSION['company_id'])||isset($_SESSION['admin_id'])): ?>
        <a href="logout.php" class="btn-ghost">Logout</a>
      <?php endif; ?>
    </nav>
    <button class="nav-toggle" aria-label="Open Menu">☰</button>
  </div>
</header>
<main class="container">
