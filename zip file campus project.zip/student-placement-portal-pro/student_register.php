<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include 'db_connect.php';
include 'header.php';


$notification = ""; // Store messages here
$max_resume_size = 2 * 1024 * 1024; // 2MB




if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $roll     = trim($_POST['roll_no']);
    $course   = trim($_POST['course']);
    $skills   = trim($_POST['skills']);

    // Length constraints
    $name_min = 2; $name_max = 100;
    $email_max = 255;
    $password_min = 6; $password_max = 128;
    $roll_min = 1; $roll_max = 10;
    $course_min = 2; $course_max = 100;

    // Name validation
    if (!preg_match("/^[a-zA-Z ]+$/", $name)) {
        $notification = '<div class="card alert">Invalid name. Only letters and spaces allowed.</div>';
    } elseif (strlen($name) < $name_min || strlen($name) > $name_max) {
        $notification = '<div class="card alert">Name must be between ' . $name_min . ' and ' . $name_max . ' characters.</div>';
    // Email validation
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $notification = '<div class="card alert">Invalid email format.</div>';
    } elseif (strlen($email) > $email_max) {
        $notification = '<div class="card alert">Email must be at most ' . $email_max . ' characters.</div>';
    // Password length
    } elseif (strlen($password) < $password_min) {
        $notification = '<div class="card alert">Password must be at least ' . $password_min . ' characters long.</div>';
    } elseif (strlen($password) > $password_max) {
        $notification = '<div class="card alert">Password must be at most ' . $password_max . ' characters long.</div>';
    // Password confirmation
    } elseif ($password !== $confirm_password) {
        $notification = '<div class="card alert">Passwords do not match.</div>';
    // Roll number validation
    } elseif (!preg_match("/^[A-Za-z0-9\\-]+$/", $roll)) {
        $notification = '<div class="card alert">Invalid roll number. Only letters, numbers and dashes allowed.</div>';
    } elseif (strlen($roll) < $roll_min || strlen($roll) > $roll_max || !preg_match('/\\d/', $roll)) {
        $notification = '<div class="card alert">Roll number must be between ' . $roll_min . ' and ' . $roll_max . ' characters and include at least one digit.</div>';
    // Course validation
    } elseif (!preg_match("/^[a-zA-Z ]+$/", $course) || empty($course)) {
        $notification = '<div class="card alert">Invalid course. Only letters and spaces allowed.</div>';
    } elseif (strlen($course) < $course_min || strlen($course) > $course_max) {
        $notification = '<div class="card alert">Course must be between ' . $course_min . ' and ' . $course_max . ' characters.</div>';
    // Skills validation: letters and common punctuation only, 2-255 chars
    } elseif (empty($skills) || strlen($skills) < 2 || strlen($skills) > 255 || !preg_match('/^[A-Za-z,\.\-\/\(\)\s]+$/', $skills)) {
        $notification = '<div class="card alert">Please enter your skills (2-255 characters, letters and common punctuation only).</div>';
    // Resume validation
    } elseif (!isset($_FILES['resume']) || $_FILES['resume']['error'] !== 0) {
        $notification = '<div class="card alert">Please upload your resume (PDF, max 2MB).</div>';
    } else {
        $ext = strtolower(pathinfo($_FILES['resume']['name'], PATHINFO_EXTENSION));
        if ($ext !== 'pdf') {
            $notification = '<div class="card alert">Only PDF files are allowed for resume.</div>';
        } elseif ($_FILES['resume']['size'] > $max_resume_size) {
            $notification = '<div class="card alert">Resume file size must be less than 2MB.</div>';
        } else {
            // Check for duplicate email
            $check = $conn->prepare("SELECT id FROM students WHERE email = ?");
            $check->bind_param('s', $email);
            $check->execute();
            $check->store_result();
            if ($check->num_rows > 0) {
                $notification = '<div class="card alert">This email is already registered. Please use another email.</div>';
            } else {
                // Hash password
                $password_hashed = password_hash($password, PASSWORD_DEFAULT);
                // Resume upload folder
                if (!is_dir('uploads')) {
                    mkdir('uploads');
                }
                $resume_name = time() . '_' . preg_replace('/\s+/', '_', $_FILES['resume']['name']);
                if (move_uploaded_file($_FILES['resume']['tmp_name'], 'uploads/' . $resume_name)) {
                    // Insert student
                    $stmt = $conn->prepare("
                        INSERT INTO students (name, email, password, roll_no, course, skills, resume)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->bind_param('sssssss', $name, $email, $password_hashed, $roll, $course, $skills, $resume_name);
                    if ($stmt->execute()) {
                        $notification = '<div class="card success">Registration successful. <a href="student_login.php">Login</a></div>';
                    } else {
                        $notification = '<div class="card alert">Error: ' . $conn->error . '</div>';
                    }
                    $stmt->close();
                } else {
                    $notification = '<div class="card alert">Resume upload failed. Please try again or use a smaller file.</div>';
                }
                // ...existing code...
            }
            $check->close();
        }
    }
}

// Fallback notification if registration logic is skipped
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($notification)) {
    $notification = '<div class="card alert">Registration did not complete. Please check your input and try again.</div>';
}
?>

<div class="card form-center">
  <h2>Student Registration</h2>

  <!-- Notification above form -->
  <?php if (!empty($notification)) echo $notification; ?>

  <form method="post" enctype="multipart/form-data">
    <label>Name</label>
    <input type="text" name="name" required minlength="2" maxlength="100" title="Name (2-100 characters)">

    <label>Email</label>
    <input type="email" name="email" required maxlength="255" title="Email (max 255 characters)">


    <label>Password</label>
    <input type="password" name="password" required minlength="6" maxlength="128" title="Password (6-128 characters)">

    <label>Confirm Password</label>
    <input type="password" name="confirm_password" required minlength="6" maxlength="128" title="Confirm password (6-128 characters)">

    <label>Roll No</label>
    <input id="roll_no" type="text" name="roll_no" pattern="(?=.*\\d)[A-Za-z0-9\\-]{1,10}" maxlength="10" title="Letters, numbers and dashes only (1-10 chars) and must include a digit" required>
    <div id="roll-error" style="color:#a94442;display:none;margin-top:6px;font-size:13px">Only letters, numbers and dashes are allowed (1-10 chars) and must include at least one digit.</div>

    <label>Course</label>
    <input type="text" name="course" required minlength="2" maxlength="100" title="Course (2-100 characters)">

        <label>Skills</label>
        <textarea id="skills" name="skills" maxlength="255" required></textarea>
        <div style="display:flex;gap:12px;align-items:center;margin-top:6px">
            <div id="skills-error" style="color:#a94442;display:none;font-size:13px">Only letters, numbers, commas, dots, hyphens, slashes and spaces allowed (2-255 chars).</div>
            <div id="skills-count" style="color:#6c757d;font-size:13px;margin-left:auto">0/255</div>
        </div>

    <label>Resume (PDF)</label>
    <input type="file" name="resume" accept=".pdf" required>

    <button type="submit" name="register" class="btn" style="margin-top:8px">Register</button>
  </form>
</div>

<?php include 'footer.php'; ?>

<script>
    (function(){
        var roll = document.getElementById('roll_no');
        var err = document.getElementById('roll-error');
        if (roll) {
            roll.addEventListener('input', function(){
                var cleaned = this.value.replace(/[^A-Za-z0-9\-]/g, '');
                if (cleaned !== this.value) this.value = cleaned;
                if (this.value.length > 0 && (this.value.length < 1 || this.value.length > 10 || !/\d/.test(this.value))) {
                    err.style.display = 'block';
                } else {
                    err.style.display = 'none';
                }
            });
        }

        var skills = document.getElementById('skills');
        var skillsErr = document.getElementById('skills-error');
        var skillsCount = document.getElementById('skills-count');
        if (skills) {
            if (skillsCount) skillsCount.textContent = skills.value.length + '/255';
            skills.addEventListener('input', function(){
                var cleaned = this.value.replace(/[^A-Za-z,\.\-\/\s]/g, '');
                if (cleaned !== this.value) this.value = cleaned;
                if (skillsCount) skillsCount.textContent = this.value.length + '/255';
                if (this.value.length > 0 && (this.value.length < 2 || this.value.length > 255)) {
                    skillsErr.style.display = 'block';
                } else {
                    skillsErr.style.display = 'none';
                }
            });
        }
    })();
</script>
