<?php
include 'db_connect.php';
session_start();

// Authentication: allow company users and admins to view this page
$is_company = isset($_SESSION['company_id']);
$is_admin   = isset($_SESSION['admin_id']);
if (!$is_company && !$is_admin) {
  header('Location: company_login.php');
  exit;
}

include 'header.php';

// Validate job_id
$job_id = isset($_GET['job_id']) ? intval($_GET['job_id']) : 0;
if ($job_id <= 0) die('Invalid');

// company id (may be null for admin viewing)
$cid = $is_company ? $_SESSION['company_id'] : 0;

// verify job belongs to this company when a company is viewing
if ($is_company) {
    $chkStmt = $conn->prepare("SELECT id FROM jobs WHERE id = ? AND company_id = ?");
    $chkStmt->bind_param('ii', $job_id, $cid);
    $chkStmt->execute();
    $chkRes = $chkStmt->get_result();
    if (!$chkRes || $chkRes->num_rows == 0) {
      if ($chkRes) $chkRes->free();
      $chkStmt->close();
      die('Unauthorized');
    }
    $chkRes->free();
    $chkStmt->close();
}

// Update applicant status (only companies can change)
if ($is_company && isset($_GET['set'], $_GET['app_id'])) {
  $new    = $_GET['set'];
  $app_id = intval($_GET['app_id']);
  $allowed = ['Pending','Shortlisted','Selected','Rejected'];

  if (in_array($new, $allowed)) {
    $stmt = $conn->prepare("UPDATE applications SET status = ? WHERE id = ?");
    $stmt->bind_param('si', $new, $app_id);
    $stmt->execute();
    $stmt->close();
  }

  header("Location: view_applicants.php?job_id=$job_id");
  exit;
}

// Add to placements if requested (only companies can add)
if ($is_company && isset($_GET['place'], $_GET['student_id'])) {
  $student_id = intval($_GET['student_id']);
  $job_id = intval($_GET['job_id']);
  $company_id = $_SESSION['company_id'];

  // Get job details
  $jstmt = $conn->prepare("SELECT title FROM jobs WHERE id = ?");
  $jstmt->bind_param('i', $job_id);
  $jstmt->execute();
  $jres = $jstmt->get_result();
  $jrow = $jres ? $jres->fetch_assoc() : null;
  if ($jres) $jres->free();
  $offer_title = $jrow ? $jrow['title'] : '';
  $jstmt->close();

  // Avoid duplicate placements
  $pstmt = $conn->prepare("SELECT id FROM placements WHERE student_id = ? AND company_id = ? AND job_id = ?");
  $pstmt->bind_param('iii', $student_id, $company_id, $job_id);
  $pstmt->execute();
  $pres = $pstmt->get_result();
  $pcount = $pres ? $pres->num_rows : 0;
  if ($pres) $pres->free();
  $pstmt->close();
  if (!$pcount) {
    $ist = $conn->prepare("INSERT INTO placements (student_id, company_id, job_id, offer_title, status) VALUES (?, ?, ?, ?, 'Offered')");
    $ist->bind_param('iiis', $student_id, $company_id, $job_id, $offer_title);
    $ist->execute();
    $ist->close();
  }
  header("Location: view_applicants.php?job_id=$job_id");
  exit;
}
?>

<div class="card">
  <h2>Applicants</h2>
  <table class="table">
    <tr>
      <th>Student</th>
      <th>Course</th>
      <th>Skills</th>
      <th>Resume</th>
      <th>Status</th>
      <th>Update</th>
    </tr>

    <?php
    $stmt = $conn->prepare("SELECT applications.id AS app_id, applications.status, applications.student_id, students.name, students.course, students.skills, students.resume FROM applications JOIN students ON applications.student_id = students.id WHERE applications.job_id = ? ORDER BY applications.id DESC");
    $stmt->bind_param('i', $job_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()):
      // Build resume link: prefer uploaded file if exists, otherwise fall back to resumes table preview
      $resume = '—';
      if (!empty($row['resume'])) {
        $rpath = __DIR__ . '/uploads/' . $row['resume'];
        $rpublic = 'uploads/' . $row['resume'];
        if (file_exists($rpath) && is_readable($rpath)) {
          $resume = '<a class="btn" target="_blank" href="serve_resume.php?sid=' . intval($row['student_id']) . '&job_id=' . intval($job_id) . '">View</a>';
        }
      }
      if ($resume === '—') {
        // check resume builder table
        $rs = $conn->prepare('SELECT id FROM resumes WHERE student_id = ? LIMIT 1');
        if ($rs) {
          $rs->bind_param('i', $row['student_id']);
          $rs->execute();
          $rres = $rs->get_result();
          $hasResume = $rres ? $rres->fetch_assoc() : null;
          $rs->close();
            if ($hasResume) {
              $resume = '<a class="btn" target="_blank" href="serve_resume.php?sid=' . intval($row['student_id']) . '&job_id=' . intval($job_id) . '">Preview</a>';
            }
        }
      }
      $addPlacementBtn = '';
      if ($row['status'] === 'Selected') {
        // Check if already placed
        $ap = $conn->prepare("SELECT id FROM placements WHERE student_id = ? AND company_id = ? AND job_id = ?");
        $ap->bind_param('iii', $row['student_id'], $cid, $job_id);
        $ap->execute();
        $apres = $ap->get_result();
        $alreadyPlaced = $apres ? $apres->num_rows : 0;
        $ap->close();
        if (!$alreadyPlaced) {
          $addPlacementBtn = '<a class="btn" style="background:#28a745;color:#fff;" href="?job_id=' . urlencode($job_id) . '&student_id=' . urlencode($row['student_id']) . '&place=1">Add to Placements</a>';
        } else {
          $addPlacementBtn = '<span style="color:#28a745;">Placed</span>';
        }
      }
    ?>
      <tr>
  <td><?= htmlspecialchars($row['name'] ?? '') ?></td>
  <td><?= htmlspecialchars($row['course'] ?? '') ?></td>
  <td><?= nl2br(htmlspecialchars($row['skills'] ?? '')) ?></td>
        <td><?= $resume ?></td>
        <td><?= htmlspecialchars($row['status']) ?></td>
        <td>
          <a class="btn" href="?job_id=<?= $job_id ?>&app_id=<?= $row['app_id'] ?>&set=Shortlisted">Shortlist</a>
          <a class="btn" href="?job_id=<?= $job_id ?>&app_id=<?= $row['app_id'] ?>&set=Selected">Select</a>
          <a class="btn" href="?job_id=<?= $job_id ?>&app_id=<?= $row['app_id'] ?>&set=Rejected">Reject</a>
          <?= $addPlacementBtn ?>
        </td>
      </tr>
    <?php endwhile; 
    if ($res) $res->free();
    $stmt->close(); ?>
  </table>
</div>

<?php include 'footer.php'; ?>
