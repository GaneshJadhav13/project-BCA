<?php
session_start();
include "db_connect.php";

// If not logged in, redirect to login
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// Save form data when submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname    = trim($_POST['fullname'] ?? '');
    $email       = trim($_POST['email'] ?? '');
    $phone       = trim($_POST['phone'] ?? '');
    $summary     = trim($_POST['summary'] ?? '');
    $education   = trim($_POST['education'] ?? '');
    $skills      = trim($_POST['skills'] ?? '');
    $projects    = trim($_POST['projects'] ?? '');
    $achievements= trim($_POST['achievements'] ?? '');
    $links       = trim($_POST['links'] ?? '');

    $errors = [];

    // Full name: letters and spaces only, 2-100 chars
    if ($fullname === '' || !preg_match('/^[A-Za-z ]{2,100}$/', $fullname)) {
        $errors[] = 'Full Name must be 2-100 letters and spaces only.';
    }

    // Email
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email address.';
    }

    // Phone: digits only, 7-15 chars
    if ($phone === '' || !preg_match('/^[0-9]{7,15}$/', $phone)) {
        $errors[] = 'Phone must be 7-15 digits.';
    }

    // Text fields: disallow digits (per request) and require minimal length
    $textFields = [
        'Summary' => $summary,
        'Education' => $education,
        'Skills' => $skills,
        'Projects' => $projects,
        'Achievements' => $achievements,
    ];
    foreach ($textFields as $label => $val) {
        if ($val !== '') {
            if (strlen($val) < 2 || strlen($val) > 2000) {
                $errors[] = "$label must be between 2 and 2000 characters.";
            } elseif (!preg_match('/^[A-Za-z,\.\-\/\(\)\s]+$/', $val)) {
                $errors[] = "$label contains invalid characters. Use letters and common punctuation only.";
            }
        }
    }

    // Links: if provided, ensure comma-separated valid URLs
    if ($links !== '') {
        $parts = array_map('trim', explode(',', $links));
        foreach ($parts as $p) {
            if ($p === '') continue;
            if (!filter_var($p, FILTER_VALIDATE_URL)) {
                $errors[] = 'Each link must be a valid URL (include http:// or https://).';
                break;
            }
        }
    }

    if (empty($errors)) {
        // Use prepared statement to insert/update
        $stmt = $conn->prepare(
            "INSERT INTO resumes (student_id, fullname, email, phone, summary, education, skills, projects, achievements, links)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE fullname = VALUES(fullname), email = VALUES(email), phone = VALUES(phone), summary = VALUES(summary), education = VALUES(education), skills = VALUES(skills), projects = VALUES(projects), achievements = VALUES(achievements), links = VALUES(links)"
        );
        $stmt->bind_param('isssssssss', $student_id, $fullname, $email, $phone, $summary, $education, $skills, $projects, $achievements, $links);
        if ($stmt->execute()) {
            $message = 'Resume saved successfully!';
        } else {
            $message = 'Error: ' . $conn->error;
        }
        $stmt->close();
    } else {
        $message = implode('<br>', $errors);
    }
}

// Fetch existing resume data if available
$resume = $conn->query("SELECT * FROM resumes WHERE student_id=$student_id")->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Resume Builder</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        h2 {
            text-align: center;
            padding: 20px;
            color: #333;
        }
        form {
            width: 80%;
            max-width: 700px;
            background: #fff;
            padding: 25px;
            margin: 0 auto;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        label {
            display: block;
            margin-top: 12px;
            font-weight: bold;
            color: #444;
        }
        input[type="text"], 
        input[type="email"], 
        textarea {
            width: 100%;
            padding: 8px 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 14px;
        }
        textarea {
            min-height: 60px;
        }
        input[type="submit"] {
            background: #4CAF50;
            color: white;
            padding: 10px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 18px;
            font-size: 15px;
        }
        input[type="submit"]:hover {
            background: #45a049;
        }
        .message {
            text-align: center;
            color: green;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .link-container {
            text-align: center;
            margin-top: 20px;
        }
        .link-container a {
            color: #0066cc;
            text-decoration: none;
        }
        .link-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<h2>Resume Builder</h2>

<?php if (!empty($message)) echo "<p class='message'>$message</p>"; ?>

<form method="post">
    <label>Full Name:</label>
    <input type="text" name="fullname" value="<?php echo $resume['fullname'] ?? ''; ?>">

    <label>Email:</label>
    <input type="email" name="email" value="<?php echo $resume['email'] ?? ''; ?>">

    <label>Phone:</label>
    <input type="text" name="phone" value="<?php echo $resume['phone'] ?? ''; ?>">

    <label>Summary:</label>
    <textarea name="summary"><?php echo $resume['summary'] ?? ''; ?></textarea>

    <label>Education:</label>
    <textarea name="education"><?php echo $resume['education'] ?? ''; ?></textarea>

    <label>Skills:</label>
    <textarea name="skills"><?php echo $resume['skills'] ?? ''; ?></textarea>

    <label>Projects:</label>
    <textarea name="projects"><?php echo $resume['projects'] ?? ''; ?></textarea>

    <label>Achievements:</label>
    <textarea name="achievements"><?php echo $resume['achievements'] ?? ''; ?></textarea>

    <label>Links (e.g. GitHub, LinkedIn):</label>
    <textarea name="links"><?php echo $resume['links'] ?? ''; ?></textarea>

    <input type="submit" value="Save Resume">
</form>

<div class="link-container">
    <a href="resume_preview.php?sid=<?php echo $student_id; ?>">Preview / Download Resume</a>
</div>

</body>
</html>

<script>
// Client-side validation and sanitization
document.addEventListener('DOMContentLoaded', function(){
    var form = document.querySelector('form');
    var fullname = form.querySelector('input[name="fullname"]');
    var phone = form.querySelector('input[name="phone"]');
    var summary = form.querySelector('textarea[name="summary"]');
    var education = form.querySelector('textarea[name="education"]');
    var skills = form.querySelector('textarea[name="skills"]');
    var projects = form.querySelector('textarea[name="projects"]');
    var achievements = form.querySelector('textarea[name="achievements"]');
    var links = form.querySelector('textarea[name="links"]');

    function sanitizeTextarea(el){
        if(!el) return;
        el.addEventListener('input', function(){
            // remove digits
            this.value = this.value.replace(/[^A-Za-z,\.\-\/\(\)\s]/g, '');
        });
    }
    sanitizeTextarea(summary);
    sanitizeTextarea(education);
    sanitizeTextarea(skills);
    sanitizeTextarea(projects);
    sanitizeTextarea(achievements);

    if(phone){
        phone.addEventListener('input', function(){
            this.value = this.value.replace(/[^0-9]/g,'');
        });
    }

    form.addEventListener('submit', function(e){
        var errors = [];
        if(!/^[A-Za-z ]{2,100}$/.test(fullname.value.trim())) errors.push('Full Name must be 2-100 letters and spaces only.');
        if(!/^[0-9]{7,15}$/.test(phone.value.trim())) errors.push('Phone must be 7-15 digits.');
        if(links && links.value.trim() !== ''){
            var parts = links.value.split(',').map(function(p){return p.trim();}).filter(Boolean);
            for(var i=0;i<parts.length;i++){
                try{ new URL(parts[i]); } catch(err){ errors.push('Each link must be a valid URL (include http:// or https://).'); break; }
            }
        }
        if(errors.length){
            e.preventDefault();
            alert(errors.join('\n'));
        }
    });
});
</script>
