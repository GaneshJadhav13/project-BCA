<?php 
include 'db_connect.php'; 
session_start();

if (!isset($_SESSION['student_id'])) {
    header('Location: student_login.php');
    exit;
}

include 'header.php'; 
?>

<?php
$sid = isset($_SESSION['student_id']) ? intval($_SESSION['student_id']) : 0;

if (isset($_POST['save'])) {
    $name   = $_POST['name']; 
    $roll   = $_POST['roll_no']; 
    $course = $_POST['course']; 
    $skills = $_POST['skills'];

    // Server-side validations
    $validation_failed = false;
    $errors = [];

    $name = trim($name);
    if ($name === '' || !preg_match('/^[a-zA-Z ]+$/', $name)) {
      $errors[] = 'Invalid name. Only letters and spaces are allowed.';
    }

    $roll = trim($roll);
    if ($roll === '' || !preg_match('/^[A-Za-z0-9\-]+$/', $roll) || strlen($roll) < 1 || strlen($roll) > 10 || !preg_match('/\d/', $roll)) {
      $errors[] = 'Invalid roll number. Use letters, numbers and dashes only (1-10 chars) and include at least one digit.';
    }

    $course = trim($course);
    if ($course === '' || !preg_match('/^[a-zA-Z ]+$/', $course)) {
      $errors[] = 'Invalid course. Only letters and spaces are allowed.';
    }

    $skills = trim($skills);
    // allow only letters, commas, dots, hyphens, slashes and spaces (no numbers)
    if ($skills === '' || strlen($skills) < 2 || strlen($skills) > 1000 || !preg_match('/^[A-Za-z,\.\-\/\s]+$/', $skills)) {
      $errors[] = 'Invalid skills. Use letters, commas, dots, hyphens, slashes and spaces only (2-1000 chars).';
    }

    // Basic photo checks (will be validated further below)
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === 0) {
      $ext_check = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
      $allowed_exts = ['jpg','jpeg','png','gif'];
      if (!in_array($ext_check, $allowed_exts)) {
        $errors[] = 'Profile photo must be an image (jpg, jpeg, png, gif).';
      }
      if (isset($_FILES['photo']['size']) && $_FILES['photo']['size'] > 2 * 1024 * 1024) {
        $errors[] = 'Profile photo must be less than 2MB.';
      }
    }

    if (!empty($errors)) {
      foreach ($errors as $err) {
        echo '<div class="card">' . htmlspecialchars($err) . '</div>';
      }
      $validation_failed = true;
    }

    if (!is_dir('uploads')) {
      mkdir('uploads', 0755, true);
    }

    $picname = '';

    if (!$validation_failed) {
      if (isset($_FILES['photo']) && $_FILES['photo']['error'] === 0) {
      // Validate file type and size (limit 2MB)
      $max_photo_size = 2 * 1024 * 1024;
      $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
      $allowed = ['jpg','jpeg','png','gif'];
      if (!in_array($ext, $allowed) || $_FILES['photo']['size'] > $max_photo_size) {
        echo '<div class="card">Invalid photo upload. Allowed: jpg,jpeg,png,gif; max 2MB.</div>';
      } else {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime  = $finfo->file($_FILES['photo']['tmp_name']);
        if (strpos($mime, 'image/') !== 0) {
          echo '<div class="card">Uploaded file is not an image.</div>';
        } else {
          // sanitize filename
          $picname = time() . '_' . preg_replace('/[^A-Za-z0-9._-]/', '_', basename($_FILES['photo']['name']));
          $target  = 'uploads/' . $picname;
          if (move_uploaded_file($_FILES['photo']['tmp_name'], $target)) {
            // prefer a dedicated `photo` column if it exists, fallback to `resume`
            $colRes = $conn->query("SHOW COLUMNS FROM students LIKE 'photo'");
            $col = ($colRes && $colRes->num_rows) ? 'photo' : 'resume';

            $sql = "UPDATE students SET $col = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('si', $picname, $sid);
            $stmt->execute();
            $stmt->close();

            $_SESSION['photo_updated'] = time();
          } else {
            echo '<div class="card">Failed to move uploaded photo.</div>';
          }
        }
      }
    }

    if (!$validation_failed) {
      $stmt = $conn->prepare(
        'UPDATE students 
         SET name   = ?, 
           roll_no = ?, 
           course  = ?, 
           skills  = ? 
         WHERE id = ?'
      );
      $stmt->bind_param('ssssi', $name, $roll, $course, $skills, $sid);

      if ($stmt->execute()) {
        $_SESSION['profile_updated'] = time();
      } else {
        echo '<div class="card">Error: ' . $conn->error . '</div>';
      }
    }

    if (isset($_SESSION['profile_updated']) && (time() - $_SESSION['profile_updated'] <= 60)) {
        echo '<div id="profile-updated-msg" class="card" style="background:#d1ecf1;color:#0c5460;">Profile updated.</div>';
        echo '<script>
                setTimeout(function(){
                    var el = document.getElementById("profile-updated-msg"); 
                    if(el) el.style.display = "none"; 
                }, 60000);
              </script>';
    } elseif (isset($_SESSION['profile_updated'])) {
        unset($_SESSION['profile_updated']);
    }

    if (isset($_SESSION['photo_updated']) && (time() - $_SESSION['photo_updated'] <= 60)) {
        echo '<div id="photo-updated-msg" class="card" style="background:#d4edda;color:#155724;">Profile photo updated successfully!</div>';
        echo '<script>
                setTimeout(function(){ 
                    var el = document.getElementById("photo-updated-msg"); 
                    if(el) el.style.display = "none"; 
                }, 60000);
              </script>';
    } elseif (isset($_SESSION['photo_updated'])) {
        unset($_SESSION['photo_updated']);
    }

    // don't double-close $stmt here; it's closed above after execute
}

// Close outer POST handler if it wasn't closed earlier
// (Ensure braces balanced after adding validation branches)
}

  $sel = $conn->prepare('SELECT * FROM students WHERE id = ?');
  $sel->bind_param('i', $sid);
  $sel->execute();
  $res = $sel->get_result();
  $me  = $res ? $res->fetch_assoc() : [];
  $sel->close();
?>

<div class="card">
  <h2>Your Profile</h2>

  <div style="display:flex; gap:18px; align-items:center; flex-wrap:wrap">
    <!-- Profile Photo (default logo if not uploaded) -->
    <img 
      src="<?php
        // prefer photo column; fallback to resume if resume is an image; otherwise default logo
        if (!empty($me['photo'])) {
          echo 'uploads/' . htmlspecialchars($me['photo']);
        } elseif (!empty($me['resume'])) {
          $rExt = strtolower(pathinfo($me['resume'], PATHINFO_EXTENSION));
          if (in_array($rExt, ['jpg','jpeg','png','gif'])) {
            echo 'uploads/' . htmlspecialchars($me['resume']);
          } else {
            echo 'assets/images/logo.png';
          }
        } else {
          echo 'assets/images/logo.png';
        }
        ?>" 
      alt="profile" 
      class="profile-img"
    >

    <div>
      <h3><?php echo htmlspecialchars($me['name'] ?? ''); ?></h3>
      <p style="color:var(--muted)">
        <?php echo htmlspecialchars($me['email'] ?? ''); ?>
      </p>

      <p>
        <strong>Roll:</strong> <?php echo htmlspecialchars($me['roll_no'] ?? ''); ?><br>
        <strong>Course:</strong> <?php echo htmlspecialchars($me['course'] ?? ''); ?><br>
        <strong>Skills:</strong> <?php echo htmlspecialchars($me['skills'] ?? ''); ?><br>
      </p>

        <?php
        // Prefer an uploaded resume (students.resume). If missing, check the resumes table.
        $resumeShown = false;
        if (!empty($me['resume'])) {
          $resumePath = __DIR__ . '/uploads/' . $me['resume'];
          $publicPath = 'uploads/' . $me['resume'];
          if (file_exists($resumePath) && is_readable($resumePath)) {
            $resExt = strtolower(pathinfo($me['resume'], PATHINFO_EXTENSION));
            // If it's a common document type, provide a direct link
            if (in_array($resExt, ['pdf','doc','docx'])) {
              echo '<p><strong>Resume:</strong> <a href="serve_resume.php?sid=' . intval($sid) . '" target="_blank">View Resume</a></p>';
              $resumeShown = true;
            } else {
              // unknown extension but file exists — allow download via secure endpoint
              echo '<p><strong>Resume:</strong> <a href="serve_resume.php?sid=' . intval($sid) . '" target="_blank">Download Resume</a></p>';
              $resumeShown = true;
            }
          } else {
            // stored filename does not point to an existing file; fall through
          }
        }

        if (!$resumeShown) {
          // Check if resume built via resume builder exists in `resumes` table
          $rstmt = $conn->prepare('SELECT id FROM resumes WHERE student_id = ? LIMIT 1');
          if ($rstmt) {
            $rstmt->bind_param('i', $sid);
            $rstmt->execute();
            $rres = $rstmt->get_result();
            $r = $rres ? $rres->fetch_assoc() : null;
            $rstmt->close();
            if ($r) {
              echo '<p><strong>Resume:</strong> <a href="serve_resume.php?sid=' . intval($sid) . '" target="_blank">Preview / Download Resume</a></p>';
              $resumeShown = true;
            }
          }
        }

        if (!$resumeShown) {
          echo '<p><strong>Resume:</strong> Not available.</p>';
        }
        ?>
    </div>
  </div>
</div>


<div class="card form-center">
  <h3>Edit Profile</h3>

  <form method="post" enctype="multipart/form-data">
    <label>Name</label>
    <input type="text" name="name" value="<?php echo htmlspecialchars($me['name'] ?? ''); ?>" required>

    <label>Roll No</label>
    <input id="roll_no" type="text" name="roll_no" pattern="(?=.*\d)[A-Za-z0-9\-]{1,10}" title="Letters, numbers and dashes only (1-10 chars) and must include a digit" maxlength="10" value="<?php echo htmlspecialchars($me['roll_no'] ?? ''); ?>" required>
    <div id="roll-error" style="color:#a94442;display:none;margin-top:6px;font-size:13px">Only letters, numbers and dashes are allowed (1-10 chars) and must include at least one digit.</div>

    <label>Course</label>
    <input type="text" name="course" value="<?php echo htmlspecialchars($me['course'] ?? ''); ?>" required>

    <label>Skills</label>
    <textarea id="skills" name="skills" maxlength="1000" required><?php echo htmlspecialchars($me['skills'] ?? ''); ?></textarea>
    <div style="display:flex;gap:12px;align-items:center;margin-top:6px">
      <div id="skills-error" style="color:#a94442;display:none;font-size:13px">Only letters, numbers, commas, dots, hyphens, slashes and spaces allowed (2-1000 chars).</div>
      <div id="skills-count" style="color:#6c757d;font-size:13px;margin-left:auto">0/1000</div>
    </div>

    <label>Profile Photo (optional)</label>
    <input type="file" name="photo" accept="image/*">

    <button type="submit" name="save" class="btn">Save</button>
  </form>
</div>

<?php include 'footer.php'; ?>

<script>
  (function(){
    var roll = document.getElementById('roll_no');
    var err = document.getElementById('roll-error');
    if(!roll) return;
    roll.addEventListener('input', function(e){
      var cleaned = this.value.replace(/[^A-Za-z0-9\-]/g, '');
      if (cleaned !== this.value) {
        this.value = cleaned;
      }
      if (this.value.length > 0 && (this.value.length < 1 || this.value.length > 10 || !/\d/.test(this.value))) {
        err.style.display = 'block';
      } else {
        err.style.display = 'none';
      }
    });
    // Skills client-side validation
    var skills = document.getElementById('skills');
    var skillsErr = document.getElementById('skills-error');
    var skillsCount = document.getElementById('skills-count');
    if (skills) {
      // set initial count
      if (skillsCount) skillsCount.textContent = skills.value.length + '/1000';
      skills.addEventListener('input', function(){
        // allow letters, numbers, commas, dots, hyphens, slashes and spaces
        var cleaned = this.value.replace(/[^A-Za-z,\.\-\/\s]/g, '');
        if (cleaned !== this.value) this.value = cleaned;
        if (skillsCount) skillsCount.textContent = this.value.length + '/1000';
        if (this.value.length > 0 && (this.value.length < 2 || this.value.length > 1000)) {
          skillsErr.style.display = 'block';
        } else {
          skillsErr.style.display = 'none';
        }
      });
    }
  })();
</script>