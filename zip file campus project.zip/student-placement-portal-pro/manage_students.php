<?php
include 'db_connect.php';
session_start();

// Redirect if not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

include 'header.php';

// Fetch students
$result = $conn->query("SELECT * FROM students ORDER BY id DESC");
?>

<div class="card">
  <h2>All Students</h2>
  <table class="table">
    <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Roll</th>
      <th>Course</th>
      <th>Resume</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($row['name'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['email'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['roll_no'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['course'] ?? '') ?></td>
        <td>
          <?php if (!empty($row['resume'])): ?>
            <a class="btn" target="_blank" href="serve_resume.php?sid=<?= $row['id'] ?>">View</a>
          <?php else: ?>
            —
          <?php endif; ?>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>
</div>

<?php include 'footer.php'; ?>
