<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0", content="#1bb566">
    <title>Placement Portal - Get Placed with Confidence</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets\styles1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<!-- Add icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



    <link rel="icon" type="image/png"href=assets/images/logo1.jpg>
    
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container header-content">
            <div class="logo">
                <i class="fas fa-graduation-cap"></i>
                <h1>PlacementPortal</h1>
            </div>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <?php if(isset($_SESSION['student_id'])): ?>
                        <li><a href="student_dashboard.php">Student Dashboard</a></li>
                        <li><a href="student_profile.php">Profile</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    <?php elseif(isset($_SESSION['company_id'])): ?>
                        <li><a href="company_dashboard.php">Company Dashboard</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    <?php elseif(isset($_SESSION['admin_id'])): ?>
                        <li><a href="admin_dashboard.php">Admin Dashboard</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    <?php else: ?>
                        <li><a href="student_login.php">Student Login</a></li>
                        <li><a href="company_login.php">Company Login</a></li>
                        <li><a href="admin_login.php">Admin Login</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container">
        <section class="hero">
            <div class="hero-content">
                <h2>Get Placed with Confidence</h2>
               <p>

The Placement Portal is designed to bridge the gap between students and employers. It helps students discover and apply for internships and job opportunities that match their skills and interests. At the same time, it offers companies a streamlined way to post openings, review applications, and connect with potential candidates - all in one place.
                 
</p>
<b><p>Built by</p></b>
<div class="cta-buttons" style="display: flex; gap: 10px; align-items: center;">
  <a href="https://www.linkedin.com/in/ganeshjadhav13/" class="btn btn-primary" style="padding: 5px 10px; margin: 2px; font-size: 14px; text-decoration: none; background-color: #007bff; color: white; border-radius: 20px;">
    Ganesh Jadhav
  </a>
  <span><b>&</b></span>
  <a href="https://www.linkedin.com/in/rudraksh-patale/" class="btn btn-secondary" style="padding: 5px 10px; font-size: 14px; text-decoration: none; background-color: #007bff; color: white; border-radius: 20px;">
    Rudraksh Patale
  </a>
</div>

                
                <div class="cta-buttons">
                    <a href="student_register.php" class="btn btn-primary">Student Register</a>
                    <a href="company_register.php" class="btn btn-secondary">Company Register</a>
                </div>
                
                <div class="features">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <h3>Student Portal</h3>
                        <p>Upload resume, apply to jobs, track status.</p>
                    </div>
                    
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-building"></i>
                        </div>
                        <h3>Company Portal</h3>
                        <p>Post drives, view applicants, shortlist & select.</p>
                    </div>
                    
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-tools"></i>
                        </div>
                        <h3>Admin Tools</h3>
                        <p>Manage users, announcements, and monitor stats.</p>
                    </div>
                </div>
            </div>
            
            <div class="hero-sidebar">
                <h3>Quick Actions</h3>
                <p>Use the links to register and get started.</p>
                <a href="student_login.php" class="btn btn-light">Student Login</a>
                <p style="margin-top: 15px; text-align: center;">or</p>
                <a href="company_login.php" class="btn btn-light">Company Login</a>
            </div>
        </section>
        
        <!-- Stats Section -->
        <section class="stats">
            <div class="stats-container">
                <div class="stat-item">
                    <div class="stat-number">5,000+</div>
                    <div class="stat-label">Students Placed</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">200+</div>
                    <div class="stat-label">Companies</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">98%</div>
                    <div class="stat-label">Success Rate</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">3,500+</div>
                    <div class="stat-label">Active Jobs</div>
                </div>
            </div>
        </section>

        <!-- Developers Section -->
        <section class="developers" style="margin: 60px 0; text-align: center;">
            <h2 style="font-size:2rem; color:#2c3e50; margin-bottom: 30px;">Meet the Developers</h2>
            <div style="display: flex; justify-content: center; gap: 40px; flex-wrap: wrap;">
                <div style="background: white; border-radius: 16px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); padding: 30px; max-width: 260px;">
                    <img src="assets/images/dev1.jpg" alt="Developer 1" style="width: 160px; height: 160px; object-fit: cover; border-radius: 50%; margin-bottom: 18px; border: 4px solid #3498db;">
                    <h3 style="margin-bottom: 8px; color:#3498db;">Rudraksh Patale</h3>
                    <p style="color:#7f8c8d;"><b>Full Stack Developer</b></p><a href="contact.php" class="btn btn-primary" 
   style="width: 120px; height: 40px; font-size: 14px; padding: 8px 12px; margin-top: 10px;">
   Contact
</a>

                </div>
                <div style="background: white; border-radius: 16px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); padding: 30px; max-width: 260px;">
                    <img src="assets/images/dev2.jpg" alt="Developer 2" style="width: 160px; height: 160px; object-fit: cover; border-radius: 50%; margin-bottom: 18px; border: 4px solid #3498db;">
                    <h3 style="margin-bottom: 8px; color:#3498db;">Ganesh Jadhav</h3>
                    <p style="color:#7f8c8d;"><b>Backend Developer</b></p>
                   <a href="contact.php" class="btn btn-primary" style="width: 120px; height: 40px; font-size: 14px; padding: 8px 12px;  margin-top:10px">Contact</a>

                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>PlacementPortal</h3>
                    <p>Connecting talented students with top companies for better career opportunities.</p>
                    <div class="social-icons">
                        <a href="https://www.instagram.com/rudrakshpatale16/?hl=en"><i class="fab fa-instagram"></i></a>
                        <a href="https://github.com/RudrakshPatale"><i class="fab fa-github"></i></a>
                        <a href="https://www.linkedin.com/in/ganeshjadhav13/"><i class="fab fa-linkedin-in"></i></a>
                        <a href="https://www.instagram.com/im.grj/?hl=en"><i class="fab fa-instagram"></i></a>
                        <a href="https://github.com/GaneshJadhav13"><i class="fab fa-github"></i></a>
                        <a href="https://www.youtube.com/@UpskillWithGanesh"><i class="fab fa-youtube"></i></a>
                        
                    </div>
                </div>
                
                <div class="footer-section">
                    <h3>Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="about.php">Services</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                    </ul>
                </div>
                
                <div class="footer-section" id="contact-section">
                    <h3>Contact Us</h3>
                    <p><i class="fas fa-map-marker-alt"></i> Iccs College, Pune </p>
                    <p><i class="fas fa-phone"></i> +123456789</p>
                    <p><i class="fas fa-envelope"></i> info@placementportal.com</p>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; 2023 PlacementPortal. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Simple animation for stats counter
        document.addEventListener('DOMContentLoaded', function() {
            const statElements = document.querySelectorAll('.stat-number');
            const values = [5000, 200, 98, 3500];
            const durations = [2000, 1500, 1000, 2500];
            
            statElements.forEach((element, index) => {
                const endValue = values[index];
                const duration = durations[index];
                let startValue = 0;
                let increment = endValue / (duration / 16);
                let currentValue = 0;
                
                const timer = setInterval(() => {
                    currentValue += increment;
                    if (currentValue >= endValue) {
                        clearInterval(timer);
                        element.textContent = endValue.toLocaleString() + (index === 2 ? '%' : '+');
                    } else {
                        element.textContent = Math.floor(currentValue).toLocaleString() + (index === 2 ? '%' : '+');
                    }
                }, 16);
            });
        });
    </script>
</body>
</html>