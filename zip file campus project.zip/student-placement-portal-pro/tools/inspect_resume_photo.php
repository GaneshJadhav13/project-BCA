<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$c = new mysqli('localhost','root','','placement_portal1');
// show columns
echo "COLUMNS in students:\n";
$res = $c->query("SHOW COLUMNS FROM students");
while($r=$res->fetch_assoc()){
    echo $r['Field'] . '\t' . $r['Type'] . '\n';
}

echo "\nRows where resume looks like an image:\n";
$res2 = $c->query("SELECT id, name, email, resume FROM students WHERE resume REGEXP '\\.(jpg|jpeg|png|gif)$'");
while($r=$res2->fetch_assoc()){
    echo $r['id'] . ' | ' . $r['email'] . ' | ' . $r['resume'] . '\n';
}

echo "\nSample resumes (non-images):\n";
$res3 = $c->query("SELECT id,email,resume FROM students WHERE resume IS NOT NULL AND resume != '' LIMIT 10");
while($r=$res3->fetch_assoc()){
    echo $r['id'] . ' | ' . $r['email'] . ' | ' . $r['resume'] . '\n';
}

echo "\nDone.\n";
?>