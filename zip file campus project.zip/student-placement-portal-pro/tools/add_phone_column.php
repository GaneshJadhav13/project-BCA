<?php
include __DIR__ . '/../db_connect.php';
$res = $conn->query("SHOW COLUMNS FROM contacts LIKE 'Phone'");
if ($res && $res->num_rows) {
    echo "Phone column already exists\n";
    exit(0);
}
$ok = $conn->query("ALTER TABLE contacts ADD COLUMN Phone VARCHAR(15) NOT NULL AFTER Email");
if ($ok) echo "Phone column added\n"; else echo "Failed: " . $conn->error . "\n";
?>