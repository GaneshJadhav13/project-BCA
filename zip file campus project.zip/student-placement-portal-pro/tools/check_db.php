<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$c = new mysqli('localhost','root','','placement_portal1');
$res = $c->query('SELECT id, email FROM students LIMIT 5');
while ($r = $res->fetch_assoc()) {
    echo $r['id'] . '|' . $r['email'] . PHP_EOL;
}
$res = $c->query('SELECT id, email FROM companies LIMIT 5');
while ($r = $res->fetch_assoc()) {
    echo 'COMPANY: ' . $r['id'] . '|' . $r['email'] . PHP_EOL;
}
echo "Done\n";
?>