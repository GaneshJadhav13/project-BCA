<?php
$e = $argv[1] ?? 'gn@gmail.com';
$c = new mysqli('localhost','root','','placement_portal1');
$stmt = $c->prepare('SELECT id,password FROM students WHERE email = ?');
$stmt->bind_param('s', $e);
$stmt->execute();
$stmt->bind_result($id,$hash);
$found = $stmt->fetch();
var_dump($found);
var_dump($id,$hash);
$stmt->close();

$stmt2 = $c->prepare('SELECT id,password FROM companies WHERE email = ?');
$stmt2->bind_param('s',$e);
$stmt2->execute();
$stmt2->bind_result($cid,$chash);
$found2 = $stmt2->fetch();
var_dump($found2);
var_dump($cid,$chash);
$stmt2->close();
?>