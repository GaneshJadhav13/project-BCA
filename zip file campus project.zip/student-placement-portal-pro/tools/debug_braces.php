<?php
$f = __DIR__ . '/../student_profile.php';
$lines = file($f);
for ($i=0;$i<count($lines);$i++){
  $n = $i+1;
  if ($n>=1 && $n<=9999) {
    if (strpos($lines[$i], '{') !== false || strpos($lines[$i], '}') !== false) {
      echo $n.': '. rtrim($lines[$i],"\n")."\n";
    }
  }
}
$all = implode('', $lines);
echo "\nTOTAL_OPEN_BRACES=".substr_count($all,'{')."\nTOTAL_CLOSE_BRACES=".substr_count($all,'}')."\n";
?>
