<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$c = new mysqli('localhost','root','','placement_portal1');
// Add photo column if missing
$colRes = $c->query("SHOW COLUMNS FROM students LIKE 'photo'");
if (!$colRes || $colRes->num_rows === 0) {
    echo "Adding 'photo' column to students...\n";
    $c->query("ALTER TABLE students ADD COLUMN photo VARCHAR(255) NULL");
} else {
    echo "'photo' column already exists.\n";
}

// Move image filenames from resume -> photo
$upd = $c->query("UPDATE students SET photo = resume, resume = NULL WHERE resume REGEXP '\\.(jpg|jpeg|png|gif)$'");
echo "Rows affected by migration: " . $c->affected_rows . "\n";

// Show resulting rows
$res = $c->query("SELECT id,email,photo,resume FROM students LIMIT 10");
while($r=$res->fetch_assoc()){
    echo $r['id'] . ' | ' . $r['email'] . ' | photo=' . ($r['photo'] ?? 'NULL') . ' | resume=' . ($r['resume'] ?? 'NULL') . "\n";
}

echo "Done.\n";
?>