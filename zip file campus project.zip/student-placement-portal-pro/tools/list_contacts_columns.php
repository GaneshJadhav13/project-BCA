<?php
include __DIR__ . '/../db_connect.php';
$res = $conn->query('SHOW COLUMNS FROM contacts');
if (!$res) {
    echo 'Query failed: ' . $conn->error . PHP_EOL;
    exit(1);
}
while ($row = $res->fetch_assoc()) {
    echo $row['Field'] . PHP_EOL;
}
?>