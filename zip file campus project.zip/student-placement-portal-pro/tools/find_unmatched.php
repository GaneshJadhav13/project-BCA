<?php
$f = __DIR__ . '/../student_profile.php';
$s = file_get_contents($f);
$len = strlen($s);
$stack = [];
$in_single = false; $in_double = false; $in_comment = false; $in_doc = false;
$line = 1;
for ($i=0;$i<$len;$i++){
    $c = $s[$i];
    $next = ($i+1<$len)?$s[$i+1]:'';
    if ($c=="\n") $line++;
    // handle // comment
    if (!$in_single && !$in_double && !$in_comment && $c=='/' && $next=='/'){
        // skip to end of line
        while ($i<$len && $s[$i] != "\n") $i++;
        $line++;
        continue;
    }
    // handle /* */ comment
    if (!$in_single && !$in_double && !$in_comment && $c=='/' && $next=='*'){
        $in_comment = true; $i++; continue;
    }
    if ($in_comment && $c=='*' && $next=='/'){
        $in_comment = false; $i++; continue;
    }
    if ($in_comment) continue;
    // handle quotes
    if (!$in_double && $c=="'"){
        // toggle single if not escaped
        $esc = ($i>0 && $s[$i-1]=='\\');
        if (!$esc) $in_single = !$in_single;
        continue;
    }
    if (!$in_single && $c=='"'){
        $esc = ($i>0 && $s[$i-1]=='\\');
        if (!$esc) $in_double = !$in_double;
        continue;
    }
    if ($in_single || $in_double) continue;
    if ($c=='{') $stack[] = $line;
    if ($c=='}') { if (empty($stack)) { echo "Unmatched closing } at line $line\n"; } else array_pop($stack); }
}
if (!empty($stack)){
    foreach ($stack as $ln) echo "Unmatched opening { at line $ln\n";
} else echo "All braces matched\n";
?>