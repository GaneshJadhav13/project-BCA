
USE if0_40041178_placement_portal1;
CREATE TABLE IF NOT EXISTS admin ( id INT PRIMARY KEY AUTO_INCREMENT, 
username VARCHAR(50) UNIQUE, 
password VARCHAR(255) );

CREATE TABLE IF NOT EXISTS students ( id INT PRIMARY KEY AUTO_INCREMENT, 
name VARCHAR(100), email VARCHAR(100) UNIQUE, 
password VARCHAR(255), roll_no VARCHAR(20),
 course VARCHAR(50), skills TEXT, 
 resume VARCHAR(255) );

 
CREATE TABLE IF NOT EXISTS companies ( id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100), email VARCHAR(100) UNIQUE, password VARCHAR(255), description TEXT );
CREATE TABLE IF NOT EXISTS jobs ( id INT PRIMARY KEY AUTO_INCREMENT, company_id INT, title VARCHAR(100), description TEXT, eligibility TEXT, last_date DATE, FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE );
CREATE TABLE IF NOT EXISTS applications ( id INT PRIMARY KEY AUTO_INCREMENT, student_id INT, job_id INT, status VARCHAR(20) DEFAULT 'Pending', FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE, FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE );
CREATE TABLE IF NOT EXISTS announcements ( id INT PRIMARY KEY AUTO_INCREMENT, title VARCHAR(100), message TEXT, date_posted DATE );

CREATE TABLE resume (
  resume_id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  education TEXT,
  skills TEXT,
  projects TEXT,
  achievements TEXT,
  CONSTRAINT fk_resume_student
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);



CREATE TABLE IF NOT EXISTS placements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    company_id INT NOT NULL,
    job_id INT NULL,
    offer_title VARCHAR(200),
    package VARCHAR(50),
    joining_date DATE,
    status ENUM('Offered','Accepted','Joined') DEFAULT 'Offered',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS resumes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    fullname VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    summary TEXT,
    education TEXT,
    skills TEXT,
    projects TEXT,
    achievements TEXT,
    links TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE(student_id),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS contacts
(
    id INT AUTO_INCREMENT PRIMARY KEY,
    FullName VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    Phone VARCHAR(15) NOT NULL,
    YourMessage TEXT NOT NULL,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
