<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/png"href=assets/images/icon.jpg>
<title>About Us - Placement Portal</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
    body {
        margin: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: #f7f8fa;
        color: #333;
        line-height: 1.6;
    }

    .hero-about {
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: linear-gradient(135deg, #3498db, #2ecc71);
        padding: 80px 70px;
        border-radius: 0 0 50px 40px;
        color: white;
        flex-wrap: wrap;
        min-height: 70vh;
    }

    .hero-text {
        flex: 1;
        min-width: 300px;
        padding-right: 30px;
    }

    .hero-about h1 {
        font-size: 3.5rem;
        margin-bottom: 25px;
        animation: fadeInDown 1s ease forwards;
        font-weight: 700;
        line-height: 1.2;
    }

    .hero-about p {
        font-size: 1.3rem;
        max-width: 600px;
        line-height: 1.8;
        animation: fadeInUp 1s ease forwards;
        opacity: 0;
        animation-delay: 0.5s;
        margin-bottom: 30px;
    }

    .hero-img {
        flex: 1;
        min-width: 300px;
        text-align: center;
    }

    .hero-img img {
        max-width: 100%;
        border-radius: 20px;
        box-shadow: 0px 15px 30px rgba(0,0,0,0.2);
        animation: fadeInRight 1s ease forwards;
        transition: transform 0.5s ease;
    }

    .hero-img img:hover {
        transform: scale(1.03);
    }

    @keyframes fadeInDown {
        0% {opacity:0; transform: translateY(-50px);}
        100% {opacity:1; transform: translateY(0);}
    }
    @keyframes fadeInUp {
        0% {opacity:0; transform: translateY(50px);}
        100% {opacity:1; transform: translateY(0);}
    }
    @keyframes fadeInRight {
        0% {opacity:0; transform: translateX(50px);}
        100% {opacity:1; transform: translateX(0);}
    }

    .container {
        width: 85%;
        max-width: 1200px;
        margin: auto;
        padding: 80px 0;
    }

    h2 {
        color: #222;
        margin-bottom: 25px;
        position: relative;
        padding-bottom: 15px;
        font-size: 2.2rem;
        font-weight: 600;
    }
    h2::after {
        content: '';
        width: 80px;
        height: 4px;
        background: #3498db;
        position: absolute;
        left: 0;
        bottom: 0;
        border-radius: 2px;
    }

    p, ul {
        line-height: 1.8;
        color: #555;
        font-size: 1.1rem;
    }

    ul {
        margin-left: 20px;
        list-style-type: disc;
    }

    .features {
        display: flex;
        flex-wrap: wrap;
        gap: 30px;
        margin-top: 50px;
    }

    .feature-card {
        flex: 1;
        min-width: 250px;
        background: white;
        padding: 35px 25px;
        border-radius: 15px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        text-align: center;
        position: relative;
        overflow: hidden;
    }

    .feature-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 5px;
        background: #3498db;
        transform: scaleX(0);
        transition: transform 0.3s ease;
    }

    .feature-card:hover::before {
        transform: scaleX(1);
    }

    .feature-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 35px rgba(0,0,0,0.15);
    }

    .feature-card i {
        font-size: 3rem;
        margin-bottom: 20px;
        color: #3498db;
        transition: transform 0.3s ease;
    }

    .feature-card:hover i {
        transform: scale(1.2);
    }

    .feature-card h3 {
        font-size: 1.5rem;
        margin-bottom: 15px;
        color: #222;
    }

    .developers {
        margin-top: 80px;
    }

    .dev-grid {
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        gap: 40px;
        margin-top: 40px;
    }

    .dev-card {
        background: #fff;
        border-radius: 20px;
        box-shadow: 0 15px 35px rgba(0,0,0,0.1);
        width: 300px;
        padding: 30px;
        text-align: center;
        transition: transform 0.4s ease, box-shadow 0.4s ease;
        position: relative;
        overflow: hidden;
    }

    .dev-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 8px;
        background: linear-gradient(to right, #3498db, #2ecc71);
    }

    .dev-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 25px 50px rgba(0,0,0,0.2);
    }

    .dev-card img {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        margin-bottom: 20px;
        object-fit: cover;
        border: 5px solid #f0f0f0;
        transition: transform 0.3s ease, border-color 0.3s ease;
    }

    .dev-card:hover img {
        transform: scale(1.1) rotate(3deg);
        border-color: #3498db;
    }

    .dev-card h3 {
        margin-bottom: 10px;
        color: #222;
        font-size: 1.4rem;
    }

    .dev-card p {
        margin-bottom: 8px;
        color: #555;
    }

    .dev-card .role {
        font-weight: 600;
        color: #3498db;
        margin-bottom: 15px;
    }

    .dev-card a {
        color: #3498db;
        text-decoration: none;
        transition: color 0.3s ease;
    }

    .dev-card a:hover {
        color: #2ecc71;
        text-decoration: underline;
    }

    .mission-vision {
        display: flex;
        gap: 40px;
        margin-top: 40px;
        flex-wrap: wrap;
    }

    .mission, .vision {
        flex: 1;
        min-width: 300px;
        background: white;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.08);
    }

    .mission h3, .vision h3 {
        color: #222;
        margin-bottom: 15px;
        font-size: 1.5rem;
    }

    .mission i, .vision i {
        font-size: 2.5rem;
        color: #3498db;
        margin-bottom: 15px;
    }

    .cta-section {
        background: linear-gradient(135deg, #3498db, #2ecc71);
        padding: 80px 0;
        text-align: center;
        color: white;
        margin-top: 60px;
        border-radius: 30px;
    }

    .cta-section h2 {
        color: white;
        margin-bottom: 20px;
    }

    .cta-section h2::after {
        background: white;
        left: 50%;
        transform: translateX(-50%);
    }

    .cta-section p {
        max-width: 700px;
        margin: 0 auto 30px;
        color: rgba(255,255,255,0.9);
    }

    .cta-button {
        display: inline-block;
        background: white;
        color: #3498db;
        padding: 15px 35px;
        border-radius: 50px;
        text-decoration: none;
        font-weight: 600;
        font-size: 1.1rem;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }

    .cta-button:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    }

    @media(max-width: 900px) {
        .hero-about {
            flex-direction: column;
            text-align: center;
            gap: 40px;
            padding: 60px 30px;
        }
        
        .hero-text {
            padding-right: 0;
        }
        
        .hero-about h1 {
            font-size: 2.8rem;
        }
        
        .hero-about p {
            font-size: 1.1rem;
        }
        
        .container {
            width: 90%;
            padding: 60px 0;
        }
    }
</style>
</head>
<body>
<?php include("header.php"); ?>

<!-- Hero Section -->
<section class="hero-about">
    <div class="hero-text">
        <h1>About Placement Portal</h1>
        <p>
            Placement Portal is your all-in-one solution for campus recruitment. 
            We connect <strong>students</strong>, <strong>companies</strong>, and <strong>college administration</strong> 
            for smooth, transparent, and efficient placement processes. 
            Track applications, manage schedules, and stay updated—all from one platform.
        </p>
        <a href="contact.php" class="cta-button">Get In Touch</a>
    </div>
    <div class="hero-img">
        <img src="assets/images/grjcollege.png" alt="Placement Portal Hero Image">
    </div>
</section>

<div class="container">
    <h2>Our Vision & Mission</h2>
    <div class="mission-vision">
        <div class="mission">
            <i class="fas fa-bullseye"></i>
            <h3>Our Mission</h3>
            <p>To empower students by providing a transparent, organized, and accessible placement platform that reduces manual processes, bridges communication gaps, and ensures both students and companies achieve their goals efficiently.</p>
        </div>
        <div class="vision">
            <i class="fas fa-eye"></i>
            <h3>Our Vision</h3>
            <p>To become the leading platform for campus recruitment, transforming how educational institutions, students, and companies interact during the placement process through innovation and technology.</p>
        </div>
    </div>

    <h2>Key Features</h2>
    <div class="features">
        <div class="feature-card">
            <i class="fas fa-user-graduate"></i>
            <h3>Student Portal</h3>
            <p>Register, upload resumes, track applications, and get placement updates in real-time with personalized recommendations.</p>
        </div>
        <div class="feature-card">
            <i class="fas fa-building"></i>
            <h3>Company Portal</h3>
            <p>Post job openings, shortlist candidates, schedule interviews, and manage recruitment workflows efficiently.</p>
        </div>
        <div class="feature-card">
            <i class="fas fa-tools"></i>
            <h3>Admin Dashboard</h3>
            <p>Manage students, companies, announcements, placement stats, and generate comprehensive reports with ease.</p>
        </div>
    </div>

    <div class="developers">
        <h2>Meet the Developers</h2>
        <div class="dev-grid">
            <div class="dev-card">
                <img src="assets/images/dev2.jpg" alt="Ganesh Jadhav">
                <h3>Ganesh Jadhav</h3>
                <p class="role">Backend Developer</p>
            </div>
            <div class="dev-card">
                <img src="assets/images/dev1.jpg" alt="Rudraksh Patale">
                <h3>Rudraksh Patale</h3>
                <p class="role">Frontend Developer</p>
                
                
            </div>
        </div>
    </div>
</div>

<section class="cta-section">
    <div class="container">
        <h2>Ready to Get Started?</h2>
        <p>Join thousands of students and companies who are already using Placement Portal to streamline their recruitment process.</p>
        <a href="contact.php" class="cta-button">Contact Us</a>
    </div>
</section>

<?php include("footer.php"); ?>
</body>
</html>